extends RefCounted
## Planet maths shared by the game code (GENERATED FILE - the same height
## function is embedded in shaders/planet_terrain.gdshader).
## The planet is a sphere of radius R centred on the world origin.

const R: float = 3000.0
const FACE_ARC: float = 4712.389
const SURFACE_GRAVITY: float = 20.0
const SPACE_START: float = 520.0
const SPACE_FULL: float = 1300.0
const H_OFFSET: float = -28.0
const START_DIR: Vector3 = Vector3(-0.913281, 0.296475, -0.2793214)
const START_HEADING: Vector3 = Vector3(0.0992928, 0.8270894, 0.5532305)

# [kx, ky, kz, amplitude, phase]
const WAVES: Array = [
	[3.76e-05, -0.0006505, 0.0002507, 120.0, 3.3585234],
	[-0.0003596, -0.0006719, -0.0004253, 100.0, 1.7988338],
	[0.0001432, 0.000207, 0.0010934, 80.0, 0.902167],
	[-1.69e-05, 0.0022815, -0.0007965, 55.0, 3.5986948],
	[0.0027677, -0.0015774, 0.0008875, 45.0, 1.7916507],
	[0.00376, 0.0022828, -0.0008909, 36.0, 0.1227325],
	[-0.0015678, -0.0074203, 0.002041, 20.0, 4.2602326],
	[0.0001495, 0.0111191, 0.0014934, 14.0, 0.5234425],
	[0.0007304, -0.0032188, -0.0162019, 9.0, 1.9874944],
	[0.0193409, -0.0134601, 0.0232022, 5.0, 5.5963229],
	[-0.012974, -0.0491264, -0.0126424, 3.0, 4.6198806],
	[-0.0314551, 0.0153922, -0.0826467, 1.6, 5.952985],
]
# [kx, ky, kz, phase]
const RIDGE: Array = [
	[-0.0017292, -0.000628, -0.0004907, 2.0786581],
	[-0.0029546, 0.0004584, -0.0001096, 2.763552],
]
const MASK_K: Vector3 = Vector3(-0.0001634, 0.0006615, -0.0007068)
const MASK_PH: float = 6.1838055

const FACE_N: Array = [Vector3(1, 0, 0), Vector3(-1, 0, 0), Vector3(0, 1, 0), Vector3(0, -1, 0), Vector3(0, 0, 1), Vector3(0, 0, -1)]
const FACE_S: Array = [Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(1, 0, 0), Vector3(1, 0, 0), Vector3(-1, 0, 0)]
const FACE_T: Array = [Vector3(0, 1, 0), Vector3(0, 1, 0), Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(0, 1, 0), Vector3(0, 1, 0)]


## Terrain height in metres above sea level for a unit direction from the planet centre.
static func height_dir(d: Vector3) -> float:
	var p: Vector3 = d * R
	var h: float = H_OFFSET
	for w in WAVES:
		h += float(w[3]) * sin(p.x * float(w[0]) + p.y * float(w[1]) + p.z * float(w[2]) + float(w[4]))
	var mask: float = clampf(0.5 + 0.5 * sin(p.dot(MASK_K) + MASK_PH), 0.0, 1.0)
	var r: float = 1.0
	for q in RIDGE:
		r *= 1.0 - absf(sin(p.x * float(q[0]) + p.y * float(q[1]) + p.z * float(q[2]) + float(q[3])))
	h += 260.0 * mask * mask * r * clampf(h / 80.0, 0.0, 1.0)
	if h < 0.0:
		h = maxf(h, -220.0) * 0.55
	return h


static func height_pos(pos: Vector3) -> float:
	return height_dir(pos.normalized())


## Direction on the unit sphere for a point (a, b) in -1..1 on cube face f.
static func face_dir(f: int, a: float, b: float) -> Vector3:
	var p: Vector3 = FACE_N[f] + FACE_S[f] * a + FACE_T[f] * b
	var x2: float = p.x * p.x
	var y2: float = p.y * p.y
	var z2: float = p.z * p.z
	var x: float = p.x * sqrt(1.0 - 0.5 * (y2 + z2) + y2 * z2 / 3.0)
	var y: float = p.y * sqrt(1.0 - 0.5 * (z2 + x2) + z2 * x2 / 3.0)
	var z: float = p.z * sqrt(1.0 - 0.5 * (x2 + y2) + x2 * y2 / 3.0)
	return Vector3(x, y, z).normalized()


static func gravity_at(r: float) -> float:
	var k: float = R / maxf(r, R * 0.5)
	return SURFACE_GRAVITY * k * k


## 0 inside the atmosphere, 1 in space (smooth between 520 m and 1300 m).
static func space_amount(altitude: float) -> float:
	return smoothstep(SPACE_START, SPACE_FULL, altitude)
