extends Node3D
## The planet: a cube-sphere quadtree. Every patch is the same 24x24 grid mesh drawn
## through ONE MultiMesh; the shader turns (face, a0, b0, size) into a piece of the
## sphere and computes the terrain height on the GPU. No meshes are generated at run time.

const PlanetMath = preload("res://scripts/planet_math.gd")

const GRID: int = 24
const MAX_PATCHES: int = 900
const MAX_DEPTH: int = 6
const SPLIT_K: float = 1.7
const STRIDE: int = 16

var patch_count: int = 0

var _mm: MultiMesh = null
var _buf: PackedFloat32Array = PackedFloat32Array()
var _count: int = 0
var _cam_pos: Vector3 = Vector3.ZERO
var _cam_dir: Vector3 = Vector3.UP
var _cam_fwd: Vector3 = Vector3.FORWARD
var _theta_vis: float = 1.0


func _ready() -> void:
	_mm = MultiMesh.new()
	_mm.transform_format = MultiMesh.TRANSFORM_3D
	_mm.use_custom_data = true
	_mm.mesh = _build_patch_mesh(GRID)
	_mm.instance_count = MAX_PATCHES
	_mm.visible_instance_count = 0
	_mm.custom_aabb = AABB(Vector3(-5000.0, -5000.0, -5000.0), Vector3(10000.0, 10000.0, 10000.0))

	_buf.resize(MAX_PATCHES * STRIDE)
	for i in range(MAX_PATCHES):
		var base: int = i * STRIDE
		_buf[base] = 1.0
		_buf[base + 5] = 1.0
		_buf[base + 10] = 1.0

	var sh: Shader = load("res://shaders/planet_terrain.gdshader") as Shader
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = sh

	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.multimesh = _mm
	mmi.material_override = mat
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.extra_cull_margin = 16384.0
	add_child(mmi)


## One flat grid in (0..1, 0, 0..1) plus a skirt (vertices with y = -1) on every edge
## that the shader pulls down to hide cracks between different levels of detail.
func _build_patch_mesh(n: int) -> ArrayMesh:
	var verts: PackedVector3Array = PackedVector3Array()
	var idx: PackedInt32Array = PackedInt32Array()
	var fn: float = float(n)
	for j in range(n + 1):
		for i in range(n + 1):
			verts.append(Vector3(float(i) / fn, 0.0, float(j) / fn))
	for j in range(n):
		for i in range(n):
			var a: int = j * (n + 1) + i
			var b: int = a + 1
			var c: int = a + (n + 1)
			var d: int = c + 1
			idx.append(a)
			idx.append(b)
			idx.append(c)
			idx.append(b)
			idx.append(d)
			idx.append(c)
	# Skirts: 4 edges.
	var edges: Array = []
	var e0: Array = []
	var e1: Array = []
	var e2: Array = []
	var e3: Array = []
	for i in range(n + 1):
		e0.append(i)                        # v = 0
		e1.append(n * (n + 1) + i)          # v = 1
		e2.append(i * (n + 1))              # u = 0
		e3.append(i * (n + 1) + n)          # u = 1
	edges.append(e0)
	edges.append(e1)
	edges.append(e2)
	edges.append(e3)
	for edge in edges:
		var base_index: int = verts.size()
		for k in range(edge.size()):
			var v: Vector3 = verts[int(edge[k])]
			verts.append(Vector3(v.x, -1.0, v.z))
		for k in range(edge.size() - 1):
			var b0: int = int(edge[k])
			var b1: int = int(edge[k + 1])
			var s0: int = base_index + k
			var s1: int = base_index + k + 1
			idx.append(b0)
			idx.append(b1)
			idx.append(s0)
			idx.append(b1)
			idx.append(s1)
			idx.append(s0)

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.custom_aabb = AABB(Vector3(-5000.0, -5000.0, -5000.0), Vector3(10000.0, 10000.0, 10000.0))
	return mesh


## Re-select the visible patches for the given camera.
func update_view(cam_pos: Vector3, cam_fwd: Vector3) -> void:
	_cam_pos = cam_pos
	_cam_fwd = cam_fwd
	var rc: float = maxf(cam_pos.length(), 1.0)
	_cam_dir = cam_pos / rc
	var ratio: float = clampf(PlanetMath.R / maxf(rc, PlanetMath.R), 0.0, 1.0)
	# Horizon angle plus an allowance for mountains that peek over it.
	_theta_vis = acos(ratio) + acos(PlanetMath.R / (PlanetMath.R + 420.0))
	_count = 0
	for f in range(6):
		_visit(f, -1.0, -1.0, 2.0, 0)
	_mm.buffer = _buf
	_mm.visible_instance_count = _count
	patch_count = _count


func _visit(f: int, a0: float, b0: float, size: float, depth: int) -> void:
	if _count >= MAX_PATCHES:
		return
	var cdir: Vector3 = PlanetMath.face_dir(f, a0 + size * 0.5, b0 + size * 0.5)
	var edge: float = size * 0.5 * PlanetMath.FACE_ARC
	var rad: float = edge * 0.8 + 260.0

	# Hidden behind the planet's horizon?
	var limit: float = minf(_theta_vis + rad / PlanetMath.R, PI)
	if _cam_dir.dot(cdir) < cos(limit):
		return
	# Entirely behind the camera?
	var center: Vector3 = cdir * PlanetMath.R
	var to_c: Vector3 = center - _cam_pos
	if to_c.dot(_cam_fwd) < -rad:
		return

	var dist: float = to_c.length()
	if depth < MAX_DEPTH and dist - rad * 0.4 < edge * SPLIT_K:
		var h: float = size * 0.5
		_visit(f, a0, b0, h, depth + 1)
		_visit(f, a0 + h, b0, h, depth + 1)
		_visit(f, a0, b0 + h, h, depth + 1)
		_visit(f, a0 + h, b0 + h, h, depth + 1)
		return

	var base: int = _count * STRIDE
	_buf[base + 12] = float(f)
	_buf[base + 13] = a0
	_buf[base + 14] = b0
	_buf[base + 15] = size
	_count += 1
