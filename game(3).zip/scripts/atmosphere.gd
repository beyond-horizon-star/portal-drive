extends RefCounted
## Sky, sun, fog and the atmosphere -> space transition.
## "space" runs 0..1 between 520 m and 1300 m altitude, so the blue sky, red horizon
## sun, stars and black space blend smoothly BEFORE the top of the atmosphere.

const PlanetMath = preload("res://scripts/planet_math.gd")

var env: Environment = null
var sun: DirectionalLight3D = null
var space: float = 0.0

var _sky_mat: ShaderMaterial = null
var _rim_mat: ShaderMaterial = null
var _rim: MeshInstance3D = null


func setup(parent: Node3D) -> void:
	_sky_mat = ShaderMaterial.new()
	_sky_mat.shader = load("res://shaders/sky.gdshader") as Shader

	var sky: Sky = Sky.new()
	sky.sky_material = _sky_mat
	sky.process_mode = Sky.PROCESS_MODE_REALTIME
	sky.radiance_size = Sky.RADIANCE_SIZE_32

	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_color = Color(0.08, 0.10, 0.20)
	env.ambient_light_sky_contribution = 0.85
	env.ambient_light_energy = 1.0
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = 1.0
	env.glow_enabled = false
	env.glow_intensity = 0.8
	env.glow_bloom = 0.04
	env.glow_hdr_threshold = 1.0
	env.fog_enabled = true
	env.fog_density = 0.0006
	env.fog_sky_affect = 0.0
	env.fog_light_color = Color(0.85, 0.6, 0.5)
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.06
	env.adjustment_saturation = 1.12

	var we: WorldEnvironment = WorldEnvironment.new()
	we.environment = env
	parent.add_child(we)

	sun = DirectionalLight3D.new()
	sun.light_color = Color(1.0, 0.72, 0.5)
	sun.light_energy = 2.3
	sun.light_angular_distance = 0.6
	sun.shadow_enabled = false
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 130.0
	sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 1.0
	parent.add_child(sun)

	_rim_mat = ShaderMaterial.new()
	_rim_mat.shader = load("res://shaders/atmo_rim.gdshader") as Shader
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = PlanetMath.R + 900.0
	sphere.height = (PlanetMath.R + 900.0) * 2.0
	sphere.radial_segments = 64
	sphere.rings = 32
	_rim = MeshInstance3D.new()
	_rim.mesh = sphere
	_rim.material_override = _rim_mat
	_rim.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_rim.visible = false
	parent.add_child(_rim)


func set_shadows(on: bool) -> void:
	if sun != null:
		sun.shadow_enabled = on


func update(cam_pos: Vector3, sun_dir: Vector3, star_basis: Basis) -> void:
	var rc: float = maxf(cam_pos.length(), 1.0)
	var up: Vector3 = cam_pos / rc
	var alt: float = rc - PlanetMath.R
	space = PlanetMath.space_amount(alt)
	var atmo: float = 1.0 - space
	var se: float = sun_dir.dot(up)

	_sky_mat.set_shader_parameter("up_dir", up)
	_sky_mat.set_shader_parameter("sun_dir", sun_dir)
	_sky_mat.set_shader_parameter("space_amt", space)
	_sky_mat.set_shader_parameter("star_rot", star_basis)

	# Sun light: warm and dim near the horizon, white and strong in space.
	var warm_f: float = (1.0 - smoothstep(0.0, 0.35, se)) * atmo
	sun.light_color = Color(1.0, 0.97, 0.92).lerp(Color(1.0, 0.50, 0.26), warm_f)
	var day_vis: float = smoothstep(-0.06, 0.12, se)
	sun.light_energy = lerpf(2.4 * day_vis, 3.0, space)
	var hint: Vector3 = Vector3(0.3, 0.9, 0.1).normalized()
	if absf(sun_dir.normalized().dot(hint)) > 0.98:
		hint = Vector3(1.0, 0.0, 0.0)
	sun.global_transform = Transform3D(Basis.looking_at(-sun_dir, hint), Vector3.ZERO)

	# Fog follows the horizon colour and disappears with altitude.
	var day: float = smoothstep(-0.10, 0.20, se)
	var hor: Color = Color(0.02, 0.03, 0.07).lerp(Color(0.62, 0.80, 1.0), day)
	var dusk: float = (1.0 - smoothstep(0.0, 0.35, se)) * smoothstep(-0.18, 0.02, se)
	var warm: Color = Color(1.0, 0.36, 0.14).lerp(Color(1.0, 0.62, 0.36), smoothstep(-0.05, 0.25, se))
	hor = hor.lerp(warm, dusk * 0.6)
	env.fog_light_color = hor
	env.fog_density = 0.0006 * (1.0 - smoothstep(60.0, 700.0, alt))
	env.ambient_light_energy = lerpf(1.0, 0.6, space)

	# Glow shell, only worth drawing from outside the atmosphere.
	_rim.visible = alt > 650.0
	if _rim.visible:
		_rim_mat.set_shader_parameter("sun_dir", sun_dir)
		_rim_mat.set_shader_parameter("strength", 1.0)
