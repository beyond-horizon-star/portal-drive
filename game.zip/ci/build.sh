#!/usr/bin/env bash
# Portal Drive - cloud build script (runs inside GitHub Actions on Ubuntu).
# All build logic lives here, inside game.zip, so the workflow file never has to change.
set -euo pipefail

GODOT_VERSION="${GODOT_VERSION:-4.5.2}"
RUN_NUMBER="${RUN_NUMBER:-1}"
ROOT="$(pwd)"

PROJECT_FILE="$(find "$ROOT/project" -name project.godot -not -path '*/.godot/*' | head -n1)"
if [ -z "$PROJECT_FILE" ]; then
  echo "::error::project.godot was not found inside game.zip"
  exit 1
fi
PROJ="$(dirname "$PROJECT_FILE")"
OUT="$ROOT/out"
mkdir -p "$OUT"
echo "Project folder: $PROJ"

# ---------------------------------------------------------------- Godot + templates
echo "::group::Download Godot ${GODOT_VERSION}"
BASE="https://github.com/godotengine/godot-builds/releases/download/${GODOT_VERSION}-stable"
curl -fL --retry 3 --retry-delay 3 -o /tmp/godot.zip "${BASE}/Godot_v${GODOT_VERSION}-stable_linux.x86_64.zip"
curl -fL --retry 3 --retry-delay 3 -o /tmp/templates.tpz "${BASE}/Godot_v${GODOT_VERSION}-stable_export_templates.tpz"
unzip -q -o /tmp/godot.zip -d /tmp/godot_bin
GODOT="/tmp/godot_bin/Godot_v${GODOT_VERSION}-stable_linux.x86_64"
chmod +x "$GODOT"
TPL="$HOME/.local/share/godot/export_templates/${GODOT_VERSION}.stable"
mkdir -p "$TPL" /tmp/tpl
unzip -q -o /tmp/templates.tpz 'templates/android*' 'templates/version.txt' -d /tmp/tpl
cp /tmp/tpl/templates/* "$TPL/"
ls -la "$TPL"
"$GODOT" --version || true
echo "::endgroup::"

# ---------------------------------------------------------------- Android SDK + Java
echo "::group::Android SDK"
export ANDROID_HOME="${ANDROID_HOME:-/usr/local/lib/android/sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKM" ]; then
  SDKM="$(find "$ANDROID_HOME" -name sdkmanager -type f | head -n1)"
fi
echo "sdkmanager: $SDKM"
(yes | "$SDKM" --licenses > /dev/null) || true
"$SDKM" "platform-tools" "build-tools;35.0.1" "platforms;android-35" | tail -n 5 || true
if [ -z "${JAVA_HOME:-}" ]; then
  JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(which javac)")")")"
  export JAVA_HOME
fi
echo "JAVA_HOME: $JAVA_HOME"
echo "::endgroup::"

# ---------------------------------------------------------------- Godot editor settings
echo "::group::Godot settings"
DEBUG_KEYSTORE="$HOME/debug.keystore"
keytool -genkeypair -keystore "$DEBUG_KEYSTORE" -alias androiddebugkey -keyalg RSA -keysize 2048 \
  -validity 10000 -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US" > /dev/null 2>&1 || true
MM="$(echo "$GODOT_VERSION" | cut -d. -f1,2)"
mkdir -p "$HOME/.config/godot"
for NAME in "editor_settings-4.tres" "editor_settings-${MM}.tres"; do
  cat > "$HOME/.config/godot/$NAME" <<EOF
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/java_sdk_path = "$JAVA_HOME"
export/android/debug_keystore = "$DEBUG_KEYSTORE"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
export/android/force_system_user = false
export/android/shutdown_adb_on_exit = true
EOF
done
ls -la "$HOME/.config/godot"
echo "::endgroup::"

# ---------------------------------------------------------------- Signing key
KEYSTORE="$PROJ/ci/release.keystore"
if [ ! -f "$KEYSTORE" ]; then
  echo "::warning::No release.keystore in game.zip - generating a temporary one (updates will not install over old builds)"
  KEYSTORE="$ROOT/release.keystore"
  keytool -genkeypair -keystore "$KEYSTORE" -alias portal -keyalg RSA -keysize 2048 -validity 36500 \
    -storepass portaldrive -keypass portaldrive -dname "CN=Portal Drive,O=Personal,C=US" > /dev/null 2>&1
fi
export GODOT_ANDROID_KEYSTORE_RELEASE_PATH="$KEYSTORE"
export GODOT_ANDROID_KEYSTORE_RELEASE_USER="portal"
export GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD="portaldrive"

# Each build gets a higher version code so Android accepts it as an update.
sed -i "s|^version/code=.*|version/code=${RUN_NUMBER}|" "$PROJ/export_presets.cfg"
sed -i "s|^version/name=.*|version/name=\"0.1.${RUN_NUMBER}\"|" "$PROJ/export_presets.cfg"

# ---------------------------------------------------------------- Import + script check
echo "::group::Import project"
set +e
"$GODOT" --headless --path "$PROJ" --import 2>&1 | tail -n 40
set -e
echo "::endgroup::"

echo "::group::Check game scripts for errors"
BAD=0
: > /tmp/check_report.txt
while IFS= read -r f; do
  set +e
  CHECK_OUT="$("$GODOT" --headless --path "$PROJ" --check-only --script "res://$f" 2>&1)"
  set -e
  if echo "$CHECK_OUT" | grep -Eq "SCRIPT ERROR|Parse Error"; then
    echo "---- ERROR in $f ----"
    echo "$CHECK_OUT"
    { echo "---- ERROR in $f ----"; echo "$CHECK_OUT" | grep -E "SCRIPT ERROR|Parse Error|at: " | head -n 12; } >> /tmp/check_report.txt
    BAD=1
  else
    echo "ok: $f"
  fi
done < <(cd "$PROJ" && find scripts -name '*.gd' | sort)
echo "::endgroup::"
if [ "$BAD" -ne 0 ]; then
  echo "::warning::GDScript errors found (the APK is still built; the errors are also pasted into the release notes)."
fi

# ---------------------------------------------------------------- Export
echo "::group::Export APK"
set +e
"$GODOT" --headless --path "$PROJ" --export-release "Android" "$OUT/PortalDrive.apk" 2>&1 | tee /tmp/export.log
set -e
echo "::endgroup::"
if [ ! -s "$OUT/PortalDrive.apk" ]; then
  echo "::error::The APK was not produced. Copy the last 40 lines of the 'Export APK' log and send them to Claude."
  exit 1
fi
ls -la "$OUT"

# ---------------------------------------------------------------- Publish
TAG="build-${RUN_NUMBER}"
NOTES="Godot ${GODOT_VERSION} - built $(date -u '+%Y-%m-%d %H:%M UTC')"
if [ -s /tmp/check_report.txt ]; then
  NOTES="${NOTES}"$'\n\n'"SCRIPT ERRORS - please send this text to Claude:"$'\n\n'"$(head -c 3500 /tmp/check_report.txt)"
fi
gh release create "$TAG" "$OUT/PortalDrive.apk" --title "Portal Drive build ${RUN_NUMBER}" --notes "$NOTES" --latest \
  || gh release upload "$TAG" "$OUT/PortalDrive.apk" --clobber
URL="https://github.com/${GH_REPO:-your/repo}/releases/tag/${TAG}"
echo "APK published: $URL"
echo "### APK ready: $URL" >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
