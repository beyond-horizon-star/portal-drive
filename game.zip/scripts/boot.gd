extends Node
## Boot loader. Starts the world and, if the world script cannot load,
## shows a readable message on screen instead of a black screen.

const WORLD_PATH: String = "res://scripts/world.gd"


func _ready() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = 100
	add_child(layer)

	var label: Label = Label.new()
	label.text = "PORTAL DRIVE\nstarting..."
	label.position = Vector2(48.0, 40.0)
	label.add_theme_font_size_override("font_size", 28)
	layer.add_child(label)

	var script: GDScript = load(WORLD_PATH) as GDScript
	if script == null or not script.can_instantiate():
		_fail(label, "The world script failed to load.")
		return

	var world: Node = script.new() as Node
	if world == null:
		_fail(label, "The world script did not start.")
		return

	world.name = "World"
	world.set("boot_label", label)
	add_child(world)


func _fail(label: Label, reason: String) -> void:
	label.text = "PORTAL DRIVE\n\nThe app installed and started correctly (pipeline OK),\nbut the game code hit a problem:\n" + reason + "\n\nPlease send a screenshot of this screen to Claude."
	label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.45))
