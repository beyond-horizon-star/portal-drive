extends RefCounted
## Terrain height function and mesh builder.
## The height field is periodic with period TILE, so the world can repeat
## seamlessly with a fixed amount of geometry (no seams, no streaming).

const TILE: float = 2048.0

# [freq_x, freq_z, amplitude, phase_x, phase_z]
const TERMS: Array = [
	[1, 1, 95.0, 0.3, 1.7],
	[2, 1, 62.0, 2.1, 0.4],
	[1, 3, 48.0, 4.0, 5.0],
	[4, 3, 30.0, 1.1, 3.3],
	[7, 5, 16.0, 0.2, 2.9],
	[11, 13, 7.0, 5.1, 1.0],
	[19, 17, 3.0, 2.2, 4.4],
]


static func height(x: float, z: float) -> float:
	var k: float = TAU / TILE
	var h: float = 24.0
	for t in TERMS:
		h += float(t[2]) * sin(k * float(t[0]) * x + float(t[3])) * sin(k * float(t[1]) * z + float(t[4]))
	if h > 0.0:
		h += h * h * 0.0035
	elif h < -30.0:
		h = -30.0 + (h + 30.0) * 0.2
	return h


static func color_at(h: float, ny: float, wob: float) -> Color:
	var sand: Color = Color(0.80, 0.69, 0.50)
	var grass: Color = Color(0.20, 0.36, 0.17)
	var forest: Color = Color(0.07, 0.20, 0.12)
	var rock: Color = Color(0.34, 0.31, 0.32)
	var snow: Color = Color(0.93, 0.95, 1.0)
	var seabed: Color = Color(0.10, 0.22, 0.28)
	var c: Color = sand
	c = c.lerp(grass, smoothstep(3.0, 14.0, h))
	c = c.lerp(forest, smoothstep(40.0, 110.0, h) * 0.9)
	c = c.lerp(rock, smoothstep(130.0, 190.0, h))
	c = c.lerp(snow, smoothstep(215.0, 250.0, h))
	c = c.lerp(rock, 1.0 - smoothstep(0.70, 0.86, ny))
	c = c.lerp(seabed, 1.0 - smoothstep(-25.0, 0.0, h))
	c = c * (0.90 + 0.20 * wob)
	c.a = 1.0
	return c


static func build_mesh(cells: int) -> ArrayMesh:
	var n: int = cells + 1
	var step: float = TILE / float(cells)
	var half: float = TILE * 0.5

	var heights: PackedFloat32Array = PackedFloat32Array()
	heights.resize(n * n)
	for iz in range(n):
		for ix in range(n):
			heights[iz * n + ix] = height(-half + float(ix) * step, -half + float(iz) * step)

	var verts: PackedVector3Array = PackedVector3Array()
	var norms: PackedVector3Array = PackedVector3Array()
	var cols: PackedColorArray = PackedColorArray()
	verts.resize(n * n)
	norms.resize(n * n)
	cols.resize(n * n)

	for iz in range(n):
		for ix in range(n):
			var i: int = iz * n + ix
			var x: float = -half + float(ix) * step
			var z: float = -half + float(iz) * step
			var h: float = heights[i]
			# Neighbours wrap around (the field is periodic) so tile edges light seamlessly.
			var ixl: int = ix - 1 if ix > 0 else n - 2
			var ixr: int = ix + 1 if ix < n - 1 else 1
			var izd: int = iz - 1 if iz > 0 else n - 2
			var izu: int = iz + 1 if iz < n - 1 else 1
			var hl: float = heights[iz * n + ixl]
			var hr: float = heights[iz * n + ixr]
			var hd: float = heights[izd * n + ix]
			var hu: float = heights[izu * n + ix]
			var nrm: Vector3 = Vector3(hl - hr, 2.0 * step, hd - hu).normalized()
			var wob: float = 0.5 + 0.25 * sin(x * 0.11) * sin(z * 0.13 + 1.0) + 0.25 * sin(x * 0.83 + z * 0.61)
			verts[i] = Vector3(x, h, z)
			norms[i] = nrm
			cols[i] = color_at(h, nrm.y, wob)

	var indices: PackedInt32Array = PackedInt32Array()
	indices.resize(cells * cells * 6)
	var w: int = 0
	for iz in range(cells):
		for ix in range(cells):
			var a: int = iz * n + ix
			var b: int = a + 1
			var c: int = a + n
			var d: int = c + 1
			indices[w] = a
			indices[w + 1] = b
			indices[w + 2] = c
			indices[w + 3] = b
			indices[w + 4] = d
			indices[w + 5] = c
			w += 6

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh
