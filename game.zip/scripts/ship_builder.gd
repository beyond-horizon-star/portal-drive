extends RefCounted
## Builds the fighter ship procedurally. The nose points along -Z (Godot forward).
## Fuselage is a smooth lofted body; wings, canards and fins are faceted prisms.

# [z, half_width, half_height, y_offset, squareness]
const STATIONS: Array = [
	[-8.2, 0.04, 0.04, 0.00, 2.2],
	[-7.0, 0.20, 0.14, 0.00, 2.2],
	[-5.6, 0.48, 0.28, 0.02, 2.4],
	[-4.0, 0.80, 0.44, 0.08, 2.6],
	[-2.2, 1.08, 0.56, 0.12, 2.8],
	[-0.2, 1.22, 0.60, 0.10, 3.0],
	[1.8, 1.20, 0.58, 0.06, 3.0],
	[3.6, 1.05, 0.52, 0.02, 3.0],
	[5.0, 0.80, 0.42, 0.00, 2.8],
	[5.6, 0.60, 0.34, 0.00, 2.6],
]
const SEGMENTS: int = 18


# ------------------------------------------------------------ materials

static func _hull(albedo: Color, metallic: float, rough: float) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = albedo
	m.metallic = metallic
	m.roughness = rough
	return m


static func _glow(col: Color, energy: float) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = Color(0.02, 0.02, 0.03)
	m.emission_enabled = true
	m.emission = col
	m.emission_energy_multiplier = energy
	return m


static func _flame_material(col: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_color = col
	return m


# ------------------------------------------------------------ mesh helpers

static func _signed_pow(v: float, e: float) -> float:
	return signf(v) * pow(absf(v), e)


# Emit a triangle whose winding makes it front-facing along n (Godot: clockwise = front).
static func _tri(vs: PackedVector3Array, ns: PackedVector3Array, a: Vector3, b: Vector3, c: Vector3, n: Vector3) -> void:
	var g: Vector3 = (b - a).cross(c - a)
	if g.dot(n) > 0.0:
		var t: Vector3 = b
		b = c
		c = t
	vs.append(a)
	vs.append(b)
	vs.append(c)
	ns.append(n)
	ns.append(n)
	ns.append(n)


# Same, with smooth per-vertex normals.
static func _tri_smooth(vs: PackedVector3Array, ns: PackedVector3Array, a: Vector3, b: Vector3, c: Vector3, na: Vector3, nb: Vector3, nc: Vector3) -> void:
	var g: Vector3 = (b - a).cross(c - a)
	if g.dot(na + nb + nc) > 0.0:
		var t: Vector3 = b
		b = c
		c = t
		var tn: Vector3 = nb
		nb = nc
		nc = tn
	vs.append(a)
	vs.append(b)
	vs.append(c)
	ns.append(na)
	ns.append(nb)
	ns.append(nc)


static func _to_mesh(vs: PackedVector3Array, ns: PackedVector3Array) -> ArrayMesh:
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vs
	arrays[Mesh.ARRAY_NORMAL] = ns
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


# Convex polygon given as (x, z) points, extruded between y0 and y1.
static func _prism_y(poly: Array, y0: float, y1: float) -> ArrayMesh:
	var vs: PackedVector3Array = PackedVector3Array()
	var ns: PackedVector3Array = PackedVector3Array()
	var cx: float = 0.0
	var cz: float = 0.0
	for p in poly:
		cx += (p as Vector2).x
		cz += (p as Vector2).y
	cx /= float(poly.size())
	cz /= float(poly.size())
	var count: int = poly.size()
	for i in range(count):
		var p0: Vector2 = poly[i] as Vector2
		var p1: Vector2 = poly[(i + 1) % count] as Vector2
		_tri(vs, ns, Vector3(cx, y1, cz), Vector3(p0.x, y1, p0.y), Vector3(p1.x, y1, p1.y), Vector3.UP)
		_tri(vs, ns, Vector3(cx, y0, cz), Vector3(p0.x, y0, p0.y), Vector3(p1.x, y0, p1.y), Vector3.DOWN)
		var ex: float = p1.x - p0.x
		var ez: float = p1.y - p0.y
		var nrm: Vector3 = Vector3(ez, 0.0, -ex).normalized()
		var mid: Vector2 = (p0 + p1) * 0.5
		if nrm.dot(Vector3(mid.x - cx, 0.0, mid.y - cz)) < 0.0:
			nrm = -nrm
		_tri(vs, ns, Vector3(p0.x, y0, p0.y), Vector3(p1.x, y0, p1.y), Vector3(p1.x, y1, p1.y), nrm)
		_tri(vs, ns, Vector3(p0.x, y0, p0.y), Vector3(p1.x, y1, p1.y), Vector3(p0.x, y1, p0.y), nrm)
	return _to_mesh(vs, ns)


# Convex polygon given as (z, y) points, extruded between x0 and x1.
static func _prism_x(poly: Array, x0: float, x1: float) -> ArrayMesh:
	var vs: PackedVector3Array = PackedVector3Array()
	var ns: PackedVector3Array = PackedVector3Array()
	var cz: float = 0.0
	var cy: float = 0.0
	for p in poly:
		cz += (p as Vector2).x
		cy += (p as Vector2).y
	cz /= float(poly.size())
	cy /= float(poly.size())
	var count: int = poly.size()
	for i in range(count):
		var p0: Vector2 = poly[i] as Vector2
		var p1: Vector2 = poly[(i + 1) % count] as Vector2
		_tri(vs, ns, Vector3(x1, cy, cz), Vector3(x1, p0.y, p0.x), Vector3(x1, p1.y, p1.x), Vector3.RIGHT)
		_tri(vs, ns, Vector3(x0, cy, cz), Vector3(x0, p0.y, p0.x), Vector3(x0, p1.y, p1.x), Vector3.LEFT)
		var ez: float = p1.x - p0.x
		var ey: float = p1.y - p0.y
		var nrm: Vector3 = Vector3(0.0, -ez, ey).normalized()
		var mid: Vector2 = (p0 + p1) * 0.5
		if nrm.dot(Vector3(0.0, mid.y - cy, mid.x - cz)) < 0.0:
			nrm = -nrm
		_tri(vs, ns, Vector3(x0, p0.y, p0.x), Vector3(x0, p1.y, p1.x), Vector3(x1, p1.y, p1.x), nrm)
		_tri(vs, ns, Vector3(x0, p0.y, p0.x), Vector3(x1, p1.y, p1.x), Vector3(x1, p0.y, p0.x), nrm)
	return _to_mesh(vs, ns)


# Smooth lofted fuselage through the cross-sections in STATIONS.
static func _fuselage() -> ArrayMesh:
	var ns_count: int = STATIONS.size()
	var grid: Array = []
	for s in range(ns_count):
		var st: Array = STATIONS[s]
		var ring: Array = []
		for j in range(SEGMENTS):
			var th: float = TAU * float(j) / float(SEGMENTS)
			var e: float = 2.0 / float(st[4])
			var x: float = float(st[1]) * _signed_pow(cos(th), e)
			var y: float = float(st[3]) + float(st[2]) * _signed_pow(sin(th), e)
			ring.append(Vector3(x, y, float(st[0])))
		grid.append(ring)

	# Smooth normals from the surface tangents.
	var normals: Array = []
	for s in range(ns_count):
		var nring: Array = []
		for j in range(SEGMENTS):
			var jm: int = (j + SEGMENTS - 1) % SEGMENTS
			var jp: int = (j + 1) % SEGMENTS
			var sm: int = maxi(s - 1, 0)
			var sp: int = mini(s + 1, ns_count - 1)
			var t_th: Vector3 = (grid[s][jp] as Vector3) - (grid[s][jm] as Vector3)
			var t_z: Vector3 = (grid[sp][j] as Vector3) - (grid[sm][j] as Vector3)
			var nrm: Vector3 = t_z.cross(t_th)
			if nrm.length() < 0.00001:
				nrm = Vector3(0.0, 0.0, -1.0)
			nrm = nrm.normalized()
			var st2: Array = STATIONS[s]
			var axis_pt: Vector3 = Vector3(0.0, float(st2[3]), float(st2[0]))
			if nrm.dot((grid[s][j] as Vector3) - axis_pt) < 0.0:
				nrm = -nrm
			nring.append(nrm)
		normals.append(nring)

	var vs: PackedVector3Array = PackedVector3Array()
	var nm: PackedVector3Array = PackedVector3Array()
	for s in range(ns_count - 1):
		for j in range(SEGMENTS):
			var j2: int = (j + 1) % SEGMENTS
			var a: Vector3 = grid[s][j] as Vector3
			var b: Vector3 = grid[s][j2] as Vector3
			var c: Vector3 = grid[s + 1][j2] as Vector3
			var d: Vector3 = grid[s + 1][j] as Vector3
			var na: Vector3 = normals[s][j] as Vector3
			var nb: Vector3 = normals[s][j2] as Vector3
			var nc: Vector3 = normals[s + 1][j2] as Vector3
			var nd: Vector3 = normals[s + 1][j] as Vector3
			_tri_smooth(vs, nm, a, b, c, na, nb, nc)
			_tri_smooth(vs, nm, a, c, d, na, nc, nd)
	# Tail cap.
	var last: Array = STATIONS[ns_count - 1]
	var cap_c: Vector3 = Vector3(0.0, float(last[3]), float(last[0]))
	for j in range(SEGMENTS):
		var j2b: int = (j + 1) % SEGMENTS
		_tri(vs, nm, cap_c, grid[ns_count - 1][j] as Vector3, grid[ns_count - 1][j2b] as Vector3, Vector3(0.0, 0.0, 1.0))
	return _to_mesh(vs, nm)


static func _add(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot_deg: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scl
	parent.add_child(mi)
	return mi


static func _box(size: Vector3) -> BoxMesh:
	var b: BoxMesh = BoxMesh.new()
	b.size = size
	return b


static func _cyl(r_top: float, r_bottom: float, h: float, seg: int) -> CylinderMesh:
	var c: CylinderMesh = CylinderMesh.new()
	c.top_radius = r_top
	c.bottom_radius = r_bottom
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	return c


static func _flame(parent: Node3D, pos: Vector3, radius: float, mat: Material) -> Node3D:
	var n: Node3D = Node3D.new()
	n.position = pos
	parent.add_child(n)
	# Cone apex points backwards (+Z); the parent's Z scale sets the flame length.
	_add(n, _cyl(0.0, radius, 1.0, 12), mat, Vector3(0.0, 0.0, 0.5), Vector3(90.0, 0.0, 0.0))
	return n


# ------------------------------------------------------------ the ship

static func build() -> Dictionary:
	var root: Node3D = Node3D.new()
	root.name = "Ship"
	var visual: Node3D = Node3D.new()
	visual.name = "Visual"
	root.add_child(visual)

	var hull: StandardMaterial3D = _hull(Color(0.035, 0.040, 0.055), 0.90, 0.30)
	var panel: StandardMaterial3D = _hull(Color(0.075, 0.080, 0.100), 0.85, 0.40)
	var glass: StandardMaterial3D = _hull(Color(0.01, 0.03, 0.06), 1.0, 0.04)
	glass.emission_enabled = true
	glass.emission = Color(0.04, 0.22, 0.42)
	glass.emission_energy_multiplier = 0.7
	var cyan: StandardMaterial3D = _glow(Color(0.2, 0.9, 1.0), 4.0)
	var violet: StandardMaterial3D = _glow(Color(0.65, 0.3, 1.0), 4.0)
	var white: StandardMaterial3D = _glow(Color(1.0, 0.97, 0.9), 6.0)
	var red: StandardMaterial3D = _glow(Color(1.0, 0.1, 0.1), 6.0)
	var green: StandardMaterial3D = _glow(Color(0.1, 1.0, 0.3), 6.0)
	var flame_mat: StandardMaterial3D = _flame_material(Color(0.45, 0.85, 1.0, 0.6))

	# Fuselage and canopy.
	_add(visual, _fuselage(), hull, Vector3.ZERO)
	var canopy: SphereMesh = SphereMesh.new()
	canopy.radius = 0.5
	canopy.height = 1.0
	canopy.radial_segments = 20
	canopy.rings = 10
	_add(visual, canopy, glass, Vector3(0.0, 0.62, -3.3), Vector3.ZERO, Vector3(0.78, 0.52, 3.2))
	# Dorsal spine behind the canopy.
	_add(visual, _box(Vector3(0.30, 0.22, 3.4)), panel, Vector3(0.0, 0.62, 1.6))

	# Wings, canards, fins (mirrored).
	var wing_poly: Array = [Vector2(0.9, -2.6), Vector2(6.0, 2.4), Vector2(6.0, 3.6), Vector2(1.0, 4.6)]
	var canard_poly: Array = [Vector2(1.0, -4.4), Vector2(2.9, -3.3), Vector2(2.9, -2.9), Vector2(1.0, -2.5)]
	var fin_poly: Array = [Vector2(3.0, 0.0), Vector2(4.2, 1.85), Vector2(5.4, 1.85), Vector2(5.2, 0.0)]
	var wing_mesh_r: ArrayMesh = _prism_y(wing_poly, -0.10, 0.06)
	var canard_mesh_r: ArrayMesh = _prism_y(canard_poly, -0.04, 0.03)
	var fin_mesh: ArrayMesh = _prism_x(fin_poly, -0.045, 0.045)
	var left_poly: Array = []
	for p in wing_poly:
		left_poly.append(Vector2(-(p as Vector2).x, (p as Vector2).y))
	var left_canard: Array = []
	for p2 in canard_poly:
		left_canard.append(Vector2(-(p2 as Vector2).x, (p2 as Vector2).y))
	var wing_mesh_l: ArrayMesh = _prism_y(left_poly, -0.10, 0.06)
	var canard_mesh_l: ArrayMesh = _prism_y(left_canard, -0.04, 0.03)

	var wing_r: MeshInstance3D = _add(visual, wing_mesh_r, hull, Vector3(0.0, -0.08, 0.0), Vector3(0.0, 0.0, -4.0))
	var wing_l: MeshInstance3D = _add(visual, wing_mesh_l, hull, Vector3(0.0, -0.08, 0.0), Vector3(0.0, 0.0, 4.0))
	_add(visual, canard_mesh_r, panel, Vector3(0.0, 0.05, 0.0))
	_add(visual, canard_mesh_l, panel, Vector3(0.0, 0.05, 0.0))
	_add(visual, fin_mesh, hull, Vector3(1.15, 0.45, 0.0), Vector3(0.0, 0.0, -14.0))
	_add(visual, fin_mesh, hull, Vector3(-1.15, 0.45, 0.0), Vector3(0.0, 0.0, 14.0))

	# Glowing leading edges and shoulder strips.
	_add(wing_r, _box(Vector3(0.05, 0.03, 7.0)), cyan, Vector3(3.45, 0.07, -0.1), Vector3(0.0, 45.5, 0.0))
	_add(wing_l, _box(Vector3(0.05, 0.03, 7.0)), cyan, Vector3(-3.45, 0.07, -0.1), Vector3(0.0, -45.5, 0.0))
	_add(visual, _box(Vector3(0.05, 0.05, 6.0)), cyan, Vector3(1.0, 0.58, 0.7))
	_add(visual, _box(Vector3(0.05, 0.05, 6.0)), cyan, Vector3(-1.0, 0.58, 0.7))

	# Wing-tip navigation lights and a tail strobe.
	var nav_mesh: SphereMesh = SphereMesh.new()
	nav_mesh.radius = 0.11
	nav_mesh.height = 0.22
	nav_mesh.radial_segments = 8
	nav_mesh.rings = 4
	_add(wing_l, nav_mesh, red, Vector3(-6.0, 0.0, 3.0))
	_add(wing_r, nav_mesh, green, Vector3(6.0, 0.0, 3.0))
	_add(visual, nav_mesh, white, Vector3(0.0, 0.8, 5.0))

	# Engine pods: nacelle, glowing intake lip, spinning-fan disc.
	var nacelle: CylinderMesh = _cyl(0.55, 0.55, 4.0, 20)
	var lip: TorusMesh = TorusMesh.new()
	lip.inner_radius = 0.50
	lip.outer_radius = 0.74
	lip.rings = 24
	lip.ring_segments = 10
	var fan: CylinderMesh = _cyl(0.50, 0.50, 0.04, 24)
	var flames: Array = []
	var fans: Array = []
	for side in [-1.0, 1.0]:
		var s: float = float(side)
		var pod: Vector3 = Vector3(3.4 * s, -0.35, 1.6)
		_add(visual, nacelle, hull, pod, Vector3(90.0, 0.0, 0.0))
		_add(visual, lip, violet, pod + Vector3(0.0, 0.0, -2.0), Vector3(90.0, 0.0, 0.0))
		var fan_node: MeshInstance3D = _add(visual, fan, violet, pod + Vector3(0.0, 0.0, -1.75), Vector3(90.0, 0.0, 0.0))
		fans.append(fan_node)
		_add(visual, _box(Vector3(0.22, 0.55, 2.4)), panel, Vector3(3.4 * s, 0.0, 1.6))
		flames.append(_flame(visual, pod + Vector3(0.0, 0.0, 2.0), 0.46, flame_mat))

	# Main engines.
	var nozzle: CylinderMesh = _cyl(0.40, 0.34, 0.8, 16)
	var nozzle_glow: CylinderMesh = _cyl(0.30, 0.30, 0.02, 16)
	for side2 in [-1.0, 1.0]:
		var s2: float = float(side2)
		_add(visual, nozzle, panel, Vector3(0.62 * s2, 0.0, 5.7), Vector3(90.0, 0.0, 0.0))
		_add(visual, nozzle_glow, white, Vector3(0.62 * s2, 0.0, 6.1), Vector3(90.0, 0.0, 0.0))
		flames.append(_flame(visual, Vector3(0.62 * s2, 0.0, 6.12), 0.36, flame_mat))

	return {
		"root": root,
		"visual": visual,
		"flames": flames,
		"fans": fans,
		"flame_mat": flame_mat,
		"nav_mats": [red, green],
	}
