extends RefCounted
## Builds the placeholder ship from primitive meshes.
## (Step 2 replaces this with the final fighter-jet style ship.)
## The ship points along -Z (Godot's forward direction).


static func _hull(albedo: Color, metallic: float, rough: float) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = albedo
	m.metallic = metallic
	m.roughness = rough
	return m


static func _glow(col: Color, energy: float) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = Color(0.02, 0.02, 0.03)
	m.emission_enabled = true
	m.emission = col
	m.emission_energy_multiplier = energy
	return m


static func _flame_material(col: Color) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_color = col
	return m


static func _add(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot_deg: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.scale = scl
	parent.add_child(mi)
	return mi


static func _box(size: Vector3) -> BoxMesh:
	var b: BoxMesh = BoxMesh.new()
	b.size = size
	return b


static func _flame(parent: Node3D, pos: Vector3, radius: float, mat: Material) -> Node3D:
	var n: Node3D = Node3D.new()
	n.position = pos
	parent.add_child(n)
	var cone: CylinderMesh = CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = radius
	cone.height = 1.0
	cone.radial_segments = 12
	cone.rings = 1
	# Cone apex points backwards (+Z); the parent's Z scale sets the flame length.
	_add(n, cone, mat, Vector3(0.0, 0.0, 0.5), Vector3(90.0, 0.0, 0.0))
	return n


static func build() -> Dictionary:
	var root: Node3D = Node3D.new()
	root.name = "Ship"
	var visual: Node3D = Node3D.new()
	visual.name = "Visual"
	root.add_child(visual)

	var hull: StandardMaterial3D = _hull(Color(0.045, 0.05, 0.065), 0.9, 0.32)
	var hull2: StandardMaterial3D = _hull(Color(0.09, 0.095, 0.12), 0.8, 0.45)
	var glass: StandardMaterial3D = _hull(Color(0.01, 0.03, 0.06), 1.0, 0.04)
	glass.emission_enabled = true
	glass.emission = Color(0.05, 0.25, 0.45)
	glass.emission_energy_multiplier = 0.6
	var cyan: StandardMaterial3D = _glow(Color(0.2, 0.9, 1.0), 4.0)
	var violet: StandardMaterial3D = _glow(Color(0.65, 0.3, 1.0), 4.0)
	var red: StandardMaterial3D = _glow(Color(1.0, 0.1, 0.1), 6.0)
	var green: StandardMaterial3D = _glow(Color(0.1, 1.0, 0.3), 6.0)
	var flame_mat: StandardMaterial3D = _flame_material(Color(0.45, 0.85, 1.0, 0.6))

	# Fuselage: a capsule lying along Z, flattened.
	var capsule: CapsuleMesh = CapsuleMesh.new()
	capsule.radius = 0.55
	capsule.height = 7.0
	capsule.radial_segments = 20
	capsule.rings = 6
	_add(visual, capsule, hull, Vector3(0.0, 0.0, 0.2), Vector3(90.0, 0.0, 0.0), Vector3(1.3, 1.0, 0.65))

	# Nose cone (apex toward -Z).
	var nose: CylinderMesh = CylinderMesh.new()
	nose.top_radius = 0.0
	nose.bottom_radius = 0.55
	nose.height = 2.8
	nose.radial_segments = 20
	nose.rings = 1
	_add(visual, nose, hull, Vector3(0.0, 0.0, -4.7), Vector3(-90.0, 0.0, 0.0), Vector3(1.3, 1.0, 0.65))

	# Glass canopy.
	var canopy: SphereMesh = SphereMesh.new()
	canopy.radius = 0.5
	canopy.height = 1.0
	canopy.radial_segments = 16
	canopy.rings = 8
	_add(visual, canopy, glass, Vector3(0.0, 0.34, -1.5), Vector3.ZERO, Vector3(0.95, 0.75, 2.6))

	# Swept wings with glowing leading edges.
	for side in [-1.0, 1.0]:
		var s: float = float(side)
		var wing: MeshInstance3D = _add(visual, _box(Vector3(5.4, 0.08, 2.8)), hull2, Vector3(3.1 * s, -0.02, 1.4), Vector3(0.0, -24.0 * s, 0.0))
		_add(wing, _box(Vector3(5.0, 0.03, 0.05)), cyan, Vector3(0.0, 0.05, -1.38))
		# Tail fin, canted outward.
		_add(visual, _box(Vector3(0.08, 1.5, 1.5)), hull2, Vector3(0.95 * s, 0.85, 2.7), Vector3(0.0, 0.0, -14.0 * s))
		# Small canard.
		_add(visual, _box(Vector3(1.6, 0.05, 0.8)), hull2, Vector3(1.05 * s, 0.0, -1.9), Vector3(0.0, -15.0 * s, 0.0))
		# Fuselage glow strip.
		_add(visual, _box(Vector3(0.04, 0.04, 4.0)), cyan, Vector3(0.62 * s, 0.2, 0.4))

	# Ring pods (ducted fans) hanging under the wings.
	var ring: TorusMesh = TorusMesh.new()
	ring.inner_radius = 0.62
	ring.outer_radius = 1.05
	ring.rings = 24
	ring.ring_segments = 12
	var fan: CylinderMesh = CylinderMesh.new()
	fan.top_radius = 0.58
	fan.bottom_radius = 0.58
	fan.height = 0.05
	fan.radial_segments = 24
	fan.rings = 1
	var trim: TorusMesh = TorusMesh.new()
	trim.inner_radius = 1.0
	trim.outer_radius = 1.08
	trim.rings = 24
	trim.ring_segments = 8
	var flames: Array = []
	for side in [-1.0, 1.0]:
		var s2: float = float(side)
		var pod_pos: Vector3 = Vector3(3.5 * s2, -0.8, 1.5)
		_add(visual, ring, hull, pod_pos, Vector3(90.0, 0.0, 0.0), Vector3(1.0, 1.0, 1.15))
		_add(visual, trim, violet, pod_pos + Vector3(0.0, 0.0, -0.02), Vector3(90.0, 0.0, 0.0), Vector3(1.0, 1.0, 1.15))
		_add(visual, fan, violet, pod_pos, Vector3(90.0, 0.0, 0.0))
		_add(visual, _box(Vector3(0.18, 0.75, 1.4)), hull2, Vector3(3.5 * s2, -0.3, 1.5))
		flames.append(_flame(visual, pod_pos + Vector3(0.0, 0.0, 0.5), 0.45, flame_mat))

	# Main engines.
	var nozzle: CylinderMesh = CylinderMesh.new()
	nozzle.top_radius = 0.30
	nozzle.bottom_radius = 0.38
	nozzle.height = 0.9
	nozzle.radial_segments = 14
	nozzle.rings = 1
	for side in [-1.0, 1.0]:
		var s3: float = float(side)
		_add(visual, nozzle, hull2, Vector3(0.5 * s3, 0.0, 3.35), Vector3(90.0, 0.0, 0.0))
		flames.append(_flame(visual, Vector3(0.5 * s3, 0.0, 3.8), 0.34, flame_mat))

	# Wing-tip navigation lights.
	var nav_mesh: SphereMesh = SphereMesh.new()
	nav_mesh.radius = 0.1
	nav_mesh.height = 0.2
	nav_mesh.radial_segments = 8
	nav_mesh.rings = 4
	_add(visual, nav_mesh, red, Vector3(-5.5, 0.08, 2.5))
	_add(visual, nav_mesh, green, Vector3(5.5, 0.08, 2.5))

	return {
		"root": root,
		"visual": visual,
		"flames": flames,
		"flame_mat": flame_mat,
		"nav_mats": [red, green],
	}
