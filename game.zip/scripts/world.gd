extends Node3D
## Portal Drive - STEP 3: bigger world (16 km planet), flat-looking ground, wavy water, rivers,
## forests, deserts, mountains, city plateaus, red growing sun, space before the atmosphere top.

const PlanetMath = preload("res://scripts/planet_math.gd")
const Planet = preload("res://scripts/planet.gd")
const Atmosphere = preload("res://scripts/atmosphere.gd")
const ShipBuilder = preload("res://scripts/ship_builder.gd")
const TouchUI = preload("res://scripts/touch_ui.gd")

const QUALITY: Array = [
	{"name": "LOW", "scale": 0.65, "shadows": false, "glow": false, "fxaa": false},
	{"name": "MED", "scale": 0.80, "shadows": true, "glow": false, "fxaa": false},
	{"name": "HIGH", "scale": 1.00, "shadows": true, "glow": true, "fxaa": true},
]
const TIMES: Array = [
	{"name": "SUNSET", "el": 16.0, "rising": false},
	{"name": "NOON", "el": 62.0, "rising": true},
	{"name": "SUNRISE", "el": 10.0, "rising": true},
	{"name": "NIGHT", "el": -35.0, "rising": false},
]
const DAY_LENGTH: float = 900.0
const FRAME_SAMPLES: int = 120
const CRASH_SPEED: float = 130.0

# Set by boot.gd before this node enters the tree.
var boot_label: Label = null

var _atmo: Atmosphere = null
var _planet: Planet = null
var _cam: Camera3D = null
var _ship: Node3D = null
var _visual: Node3D = null
var _flames: Array = []
var _flame_mat: StandardMaterial3D = null
var _nav_mats: Array = []
var _hud: Label = null
var _loading: Label = null
var _toast: Label = null
var _touch: TouchUI = null

var _ready_done: bool = false
var _time: float = 0.0
var _toast_t: float = 0.0
var _quality: int = 0
var _time_idx: int = 0
var _site_idx: int = 0

# Ship state.
var _pos: Vector3 = Vector3.ZERO
var _basis: Basis = Basis.IDENTITY
var _cam_basis: Basis = Basis.IDENTITY
var _throttle: float = 0.45
var _s_par: float = 120.0
var _drift: Vector3 = Vector3.ZERO
var _roll_vis: float = 0.0
var _speed_now: float = 0.0

# Sun / stars.
var _sun_base: Vector3 = Vector3.UP
var _sun_axis: Vector3 = Vector3.RIGHT
var _sun_angle: float = 0.0
var _sun_dir: Vector3 = Vector3.UP

var _frame_ms: PackedFloat32Array = PackedFloat32Array()
var _frame_i: int = 0
var _hud_t: float = 0.0
var _lod_tick: int = 0


func _ready() -> void:
	_frame_ms.resize(FRAME_SAMPLES)
	_build_hud_layer()
	_set_loading("Building planet...")
	await get_tree().process_frame
	await get_tree().process_frame

	_atmo = Atmosphere.new()
	_atmo.setup(self)
	_cam = Camera3D.new()
	_cam.fov = 70.0
	_cam.near = 0.5
	_cam.far = 400000.0
	add_child(_cam)
	_cam.make_current()

	_planet = Planet.new()
	add_child(_planet)
	_build_ship()
	_init_sun()
	_respawn()

	_apply_safe_area()
	_apply_quality()
	_loading.visible = false
	if boot_label != null:
		boot_label.visible = false
	_ready_done = true
	_show_toast("Left stick: throttle / roll    Right stick: aim    Fly up to reach space")


func _set_loading(text: String) -> void:
	if _loading != null:
		_loading.text = "PORTAL DRIVE\n" + text


func _show_toast(text: String) -> void:
	_toast.text = text
	_toast.visible = true
	_toast_t = 4.0


# ---------------------------------------------------------------- setup

func _style_label(l: Label, font_size: int) -> void:
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color(0.86, 0.97, 1.0))
	l.add_theme_color_override("font_outline_color", Color(0.0, 0.02, 0.05, 0.85))
	l.add_theme_constant_override("outline_size", 5)


func _build_hud_layer() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	_hud = Label.new()
	_hud.position = Vector2(20.0, 12.0)
	_style_label(_hud, 15)
	layer.add_child(_hud)

	_loading = Label.new()
	_style_label(_loading, 30)
	_loading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_loading.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	layer.add_child(_loading)
	_loading.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_toast = Label.new()
	_style_label(_toast, 22)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	_toast.visible = false
	layer.add_child(_toast)
	_toast.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_toast.offset_bottom = -26.0

	_touch = TouchUI.new()
	layer.add_child(_touch)
	_touch.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_touch.button_pressed.connect(_on_button)


func _apply_safe_area() -> void:
	var win: Vector2i = DisplayServer.window_get_size()
	var safe: Rect2i = DisplayServer.get_display_safe_area()
	var vp: Vector2 = get_viewport().get_visible_rect().size
	if win.x <= 0 or win.y <= 0 or safe.size.x <= 0 or safe.size.y <= 0:
		return
	var sx: float = vp.x / float(win.x)
	var sy: float = vp.y / float(win.y)
	var l: float = clampf(float(safe.position.x) * sx, 0.0, 160.0)
	var t: float = clampf(float(safe.position.y) * sy, 0.0, 80.0)
	var r: float = clampf(float(win.x - (safe.position.x + safe.size.x)) * sx, 0.0, 160.0)
	var b: float = clampf(float(win.y - (safe.position.y + safe.size.y)) * sy, 0.0, 80.0)
	_touch.apply_safe_area(l, t, r, b)
	_hud.position = Vector2(l + 20.0, t + 12.0)


func _build_ship() -> void:
	var parts: Dictionary = ShipBuilder.build()
	_ship = parts["root"] as Node3D
	_visual = parts["visual"] as Node3D
	_flames = parts["flames"] as Array
	_flame_mat = parts["flame_mat"] as StandardMaterial3D
	_nav_mats = parts["nav_mats"] as Array
	add_child(_ship)


func _init_sun() -> void:
	var up0: Vector3 = PlanetMath.START_DIR
	var hd: Vector3 = PlanetMath.START_HEADING
	var side: Vector3 = (Basis(up0, deg_to_rad(-50.0)) * hd).normalized()
	var el: float = deg_to_rad(22.0)
	_sun_base = (up0 * sin(el) + side * cos(el)).normalized()
	_sun_axis = _sun_base.cross(Vector3(0.18, 0.95, 0.25)).normalized()
	# The sun is SETTING at the start so the red, growing horizon sun can be enjoyed.
	var test: Vector3 = Basis(_sun_axis, 0.05) * _sun_base
	if test.dot(up0) > _sun_base.dot(up0):
		_sun_axis = -_sun_axis
	_sun_angle = 0.0
	_sun_dir = _sun_base


func _set_time_of_day(el_deg: float, rising_wanted: bool) -> void:
	var up: Vector3 = _pos.normalized()
	var target: float = sin(deg_to_rad(el_deg))
	var best: float = _sun_angle
	var best_err: float = 1.0e9
	var steps: int = 360
	for i in range(steps):
		var a: float = TAU * float(i) / float(steps)
		var d1: Vector3 = Basis(_sun_axis, a) * _sun_base
		var d2: Vector3 = Basis(_sun_axis, a + 0.02) * _sun_base
		var rising: bool = d2.dot(up) > d1.dot(up)
		var err: float = absf(d1.dot(up) - target)
		if rising == rising_wanted and err < best_err:
			best_err = err
			best = a
	_sun_angle = best


func _respawn() -> void:
	_warp_to(0)


## Fly to one of the showcase places (waterfalls, city, desert, mountains, forest, open sea).
func _warp_to(i: int) -> void:
	var s: Dictionary = PlanetMath.SITES[i]
	var up: Vector3 = (s["dir"] as Vector3).normalized()
	var ground: float = maxf(PlanetMath.height_dir(up), 0.0)
	_pos = up * (PlanetMath.R + ground + float(s["alt"]))
	var hd: Vector3 = s["heading"] as Vector3
	hd = (hd - up * hd.dot(up)).normalized()
	_basis = Basis.looking_at(hd, up).orthonormalized()
	_cam_basis = _basis
	_throttle = 0.35
	_s_par = 90.0
	_drift = Vector3.ZERO
	_snap_camera()


func _snap_camera() -> void:
	_ship.global_transform = Transform3D(_basis, _pos)
	_cam.global_position = _pos + _basis * Vector3(0.0, 7.0, 30.0)
	_cam.look_at(_pos + _basis * Vector3(0.0, 0.0, -26.0), _basis.y)
	_planet.update_bend(_cam.global_position, 0.0)
	_planet.update_view(_cam.global_position, -_cam.global_transform.basis.z)


## Respawn at the SAME place (after a crash or on the RESPAWN button): level, safely above ground.
func _respawn_here(reason: String) -> void:
	var rc: float = _pos.length()
	var up: Vector3 = _pos / rc
	var ground: float = maxf(PlanetMath.height_dir(up), 0.0)
	var agl: float = rc - (PlanetMath.R + ground)
	if agl < 120.0:
		_pos = up * (PlanetMath.R + ground + 120.0)
	var f: Vector3 = -_basis.z
	f = f - up * f.dot(up)
	if f.length() < 0.2:
		f = PlanetMath.START_HEADING - up * PlanetMath.START_HEADING.dot(up)
	f = f.normalized()
	_basis = Basis.looking_at(f, up).orthonormalized()
	_cam_basis = _basis
	_throttle = 0.4
	_s_par = 110.0
	_drift = Vector3.ZERO
	_snap_camera()
	_show_toast(reason)


# ---------------------------------------------------------------- buttons

func _on_button(id: String) -> void:
	if id == "quality":
		_quality = (_quality + 1) % QUALITY.size()
		_apply_quality()
	elif id == "time":
		_time_idx = (_time_idx + 1) % TIMES.size()
		var t: Dictionary = TIMES[_time_idx]
		_set_time_of_day(float(t["el"]), bool(t["rising"]))
		_show_toast(String(t["name"]))
	elif id == "sites":
		_site_idx = (_site_idx + 1) % PlanetMath.SITES.size()
		_warp_to(_site_idx)
		_show_toast(String(PlanetMath.SITES[_site_idx]["name"]))
	elif id == "reset":
		_respawn_here("Respawned here")


func _apply_quality() -> void:
	var q: Dictionary = QUALITY[_quality]
	var vp: Viewport = get_viewport()
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	vp.scaling_3d_scale = float(q["scale"])
	if bool(q["fxaa"]):
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
	else:
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
	_atmo.set_shadows(bool(q["shadows"]))
	_atmo.env.glow_enabled = bool(q["glow"])
	_touch.set_button_text("quality", "QUALITY: " + String(q["name"]))


# ---------------------------------------------------------------- per frame

func _process(delta: float) -> void:
	if not _ready_done:
		return
	_time += delta
	_frame_ms[_frame_i] = delta * 1000.0
	_frame_i = (_frame_i + 1) % FRAME_SAMPLES
	var dt: float = minf(delta, 0.05)

	_update_flight(dt)
	_update_camera(dt)

	# Time of day: slows to a stop as you leave the planet.
	_sun_angle = fmod(_sun_angle + TAU / DAY_LENGTH * dt * (1.0 - _atmo.space), TAU)
	_sun_dir = (Basis(_sun_axis, _sun_angle) * _sun_base).normalized()
	_atmo.update(_cam.global_position, _sun_dir, Basis(_sun_axis, -_sun_angle))

	_planet.update_bend(_cam.global_position, _atmo.night)
	_lod_tick += 1
	if _lod_tick >= 5:
		_lod_tick = 0
		_planet.update_view(_cam.global_position, -_cam.global_transform.basis.z)

	_animate_ship()

	if _toast_t > 0.0:
		_toast_t -= delta
		if _toast_t <= 0.0:
			_toast.visible = false

	_hud_t += delta
	if _hud_t >= 0.25:
		_hud_t = 0.0
		_update_hud()


func _update_flight(dt: float) -> void:
	var l: Vector2 = _touch.left_vec
	var r: Vector2 = _touch.right_vec
	var rc: float = _pos.length()
	var up: Vector3 = _pos / rc
	var space: float = _atmo.space
	var atmo: float = 1.0 - space

	# Left stick up/down sets the throttle and it stays where you leave it.
	_throttle = clampf(_throttle - l.y * 0.8 * dt, 0.0, 1.0)

	# Aiming: right stick turns (yaw) and pitches; left stick sideways rolls.
	_basis = Basis(_basis.y, -r.x * 1.1 * dt) * _basis
	_basis = Basis(_basis.x, -r.y * 1.1 * dt) * _basis
	_basis = Basis(-_basis.z, l.x * 1.7 * dt) * _basis
	var fwd: Vector3 = -_basis.z
	# In the atmosphere the ship levels itself against the planet's horizon.
	var ideal_right: Vector3 = fwd.cross(up)
	if ideal_right.length() > 0.2:
		ideal_right = ideal_right.normalized()
		var ang: float = _basis.x.signed_angle_to(ideal_right, fwd)
		var lvl: float = (1.0 - absf(l.x)) * atmo * 1.6
		_basis = Basis(fwd, ang * clampf(lvl * dt, 0.0, 1.0)) * _basis
	_basis = _basis.orthonormalized()
	fwd = -_basis.z

	# Speed along the nose: cruise-control style.
	var vmax: float = lerpf(380.0, 3000.0, space)
	var boost: float = 1.0
	if _touch.boost_held:
		boost = 1.7
	var v_des: float = _throttle * vmax * boost
	var accel: float = lerpf(220.0, 800.0, space)
	var brake: float = lerpf(140.0, 400.0, space)
	if v_des > _s_par:
		_s_par = minf(_s_par + accel * dt, v_des)
	else:
		_s_par = maxf(_s_par - brake * dt, v_des)

	# Gravity: lift holds the ship up above ~90 m/s in air; weaker pull in space.
	var g: float = PlanetMath.gravity_at(rc)
	var stall: float = 1.0 - clampf(_s_par / 110.0, 0.0, 1.0)
	var gf: float = lerpf(stall, 0.45, space)
	_drift += (-up) * g * gf * dt
	_drift *= exp(-lerpf(0.9, 0.12, space) * dt)

	var vel: Vector3 = fwd * _s_par + _drift
	_speed_now = vel.length()
	_pos += vel * dt

	# Ground contact.
	rc = _pos.length()
	up = _pos / rc
	var ground_r: float = PlanetMath.R + maxf(PlanetMath.height_dir(up), 0.0) + 5.0
	if rc < ground_r:
		var vn: float = vel.dot(up)
		_pos = up * ground_r
		var dn: float = _drift.dot(up)
		if dn < 0.0:
			_drift -= up * dn
		if vn < -CRASH_SPEED:
			_respawn_here("CRASHED - respawned at the same place")
			return

	_roll_vis = lerpf(_roll_vis, -r.x * 0.5 + l.x * 0.15, 1.0 - exp(-5.0 * dt))
	_ship.global_transform = Transform3D(_basis, _pos)
	_visual.rotation = Vector3(0.0, 0.0, _roll_vis)


func _update_camera(dt: float) -> void:
	_cam_basis = _cam_basis.slerp(_basis, 1.0 - exp(-6.0 * dt)).orthonormalized()
	var cp: Vector3 = _pos + _cam_basis * Vector3(0.0, 7.0, 30.0)
	var rc: float = cp.length()
	var ground: float = PlanetMath.R + maxf(PlanetMath.height_dir(cp / rc), 0.0) + 3.0
	if rc < ground:
		cp = cp / rc * ground
	_cam.global_position = cp
	_cam.look_at(_pos + _cam_basis * Vector3(0.0, 0.0, -26.0), _cam_basis.y)
	var vmax: float = lerpf(380.0, 3000.0, _atmo.space)
	var fov_target: float = 70.0 + clampf(_s_par / vmax, 0.0, 1.7) * 11.0
	_cam.fov = lerpf(_cam.fov, fov_target, 1.0 - exp(-4.0 * dt))


func _animate_ship() -> void:
	var boost_amt: float = 0.0
	if _touch.boost_held:
		boost_amt = 1.0
	var flame_len: float = 0.7 + 3.2 * _throttle + 1.4 * boost_amt
	for f in _flames:
		var n: Node3D = f as Node3D
		var flick: float = 1.0 + 0.08 * sin(_time * 47.0 + n.position.x * 3.0)
		n.scale = Vector3(flick, flick, flame_len * flick)
	if _flame_mat != null:
		_flame_mat.albedo_color = Color(0.45 + 0.3 * boost_amt, 0.85, 1.0, 0.5 + 0.35 * boost_amt)
	if _nav_mats.size() >= 2:
		var red_mat: StandardMaterial3D = _nav_mats[0] as StandardMaterial3D
		var green_mat: StandardMaterial3D = _nav_mats[1] as StandardMaterial3D
		var red_on: bool = fmod(_time, 1.2) < 0.15
		var green_on: bool = fmod(_time + 0.6, 1.2) < 0.15
		red_mat.emission_energy_multiplier = 8.0 if red_on else 0.3
		green_mat.emission_energy_multiplier = 8.0 if green_on else 0.3


func _update_hud() -> void:
	var sum: float = 0.0
	var worst: float = 0.0
	var count: int = 0
	for i in range(FRAME_SAMPLES):
		var v: float = _frame_ms[i]
		if v > 0.0:
			sum += v
			count += 1
			worst = maxf(worst, v)
	var avg: float = 0.0
	if count > 0:
		avg = sum / float(count)

	var rc: float = _pos.length()
	var up: Vector3 = _pos / rc
	var alt: float = rc - PlanetMath.R
	var agl: float = rc - (PlanetMath.R + maxf(PlanetMath.height_dir(up), 0.0))
	var zone: String = "ATMOSPHERE"
	if _atmo.space > 0.98:
		zone = "SPACE"
	elif _atmo.space > 0.02:
		zone = "LEAVING ATMOSPHERE"
	var sun_el: float = rad_to_deg(asin(clampf(_sun_dir.dot(up), -1.0, 1.0)))

	var method: String = "?"
	if RenderingServer.has_method("get_current_rendering_method"):
		method = str(RenderingServer.call("get_current_rendering_method"))
	var q: Dictionary = QUALITY[_quality]

	var lines: PackedStringArray = PackedStringArray()
	lines.append("PORTAL DRIVE  step 3b: world v2")
	lines.append("FPS %d    %.1f ms avg / %.1f ms worst    Quality %s (%.2f)" % [int(Engine.get_frames_per_second()), avg, worst, String(q["name"]), float(q["scale"])])
	lines.append("Speed %d m/s   Throttle %d%%   %s" % [int(_speed_now), int(_throttle * 100.0), zone])
	lines.append("Altitude %d m   Above ground %d m   Sun %d deg   Space at %d m" % [int(alt), int(agl), int(sun_el), int(PlanetMath.SPACE_FULL)])
	lines.append("Patches %d   Draw calls %d   Tris %dk   %s" % [_planet.patch_count, int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)), int(Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME) / 1000.0), method])
	lines.append("GPU %s    %s" % [RenderingServer.get_video_adapter_name(), OS.get_model_name()])
	_hud.text = "\n".join(lines)
