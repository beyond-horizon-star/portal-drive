extends Node3D
## Portal Drive - STEP 1: pipeline and performance test.
## A small flyable scene that proves the APK pipeline and measures what the phone can do.

const Terrain = preload("res://scripts/terrain.gd")
const ShipBuilder = preload("res://scripts/ship_builder.gd")
const TouchUI = preload("res://scripts/touch_ui.gd")

const QUALITY: Array = [
	{"name": "HIGH", "scale": 1.0, "shadows": true, "glow": true, "fxaa": true},
	{"name": "MED", "scale": 0.8, "shadows": true, "glow": true, "fxaa": false},
	{"name": "LOW", "scale": 0.6, "shadows": false, "glow": false, "fxaa": false},
]
const CITY_LEVELS: Array = [0, 2500, 5000, 10000, 20000, 30000]
const CITY_MAX: int = 30000
const FRAME_SAMPLES: int = 120

# Set by boot.gd before this node enters the tree.
var boot_label: Label = null

var _env: Environment = null
var _sun: DirectionalLight3D = null
var _cam: Camera3D = null
var _ship: Node3D = null
var _visual: Node3D = null
var _flames: Array = []
var _flame_mat: StandardMaterial3D = null
var _nav_mats: Array = []
var _terrain_root: Node3D = null
var _sea: MeshInstance3D = null
var _city: MultiMeshInstance3D = null
var _city_mm: MultiMesh = null
var _city_site: Vector2 = Vector2.ZERO
var _hud: Label = null
var _loading: Label = null
var _touch: TouchUI = null

var _ready_done: bool = false
var _time: float = 0.0
var _yaw: float = 0.0
var _pitch: float = 0.0
var _roll: float = 0.0
var _speed: float = 90.0
var _target_speed: float = 90.0
var _quality: int = 1
var _city_level: int = 2

var _frame_ms: PackedFloat32Array = PackedFloat32Array()
var _frame_i: int = 0
var _hud_t: float = 0.0


func _ready() -> void:
	_frame_ms.resize(FRAME_SAMPLES)
	_build_hud_layer()
	_set_loading("Setting up sky...")
	_setup_environment()
	_setup_camera()
	await _yield_frames(2)

	_set_loading("Building terrain...")
	await _yield_frames(2)
	_build_terrain()
	_build_sea()
	_city_site = _find_city_site()

	_set_loading("Building ship...")
	await _yield_frames(1)
	_build_ship()

	_set_loading("Building city...")
	await _yield_frames(1)
	await _build_city()

	_apply_safe_area()
	_apply_quality()
	_apply_city()
	_loading.visible = false
	if boot_label != null:
		boot_label.visible = false
	_ready_done = true


func _yield_frames(n: int) -> void:
	for i in range(n):
		await get_tree().process_frame


func _set_loading(text: String) -> void:
	if _loading != null:
		_loading.text = "PORTAL DRIVE\n" + text


# ---------------------------------------------------------------- setup

func _style_label(l: Label, font_size: int) -> void:
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color(0.86, 0.97, 1.0))
	l.add_theme_color_override("font_outline_color", Color(0.0, 0.02, 0.05, 0.85))
	l.add_theme_constant_override("outline_size", 5)


func _build_hud_layer() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	_hud = Label.new()
	_hud.position = Vector2(20.0, 12.0)
	_style_label(_hud, 16)
	layer.add_child(_hud)

	_loading = Label.new()
	_style_label(_loading, 30)
	_loading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_loading.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	layer.add_child(_loading)
	_loading.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_touch = TouchUI.new()
	layer.add_child(_touch)
	_touch.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_touch.button_pressed.connect(_on_button)


func _apply_safe_area() -> void:
	var win: Vector2i = DisplayServer.window_get_size()
	var safe: Rect2i = DisplayServer.get_display_safe_area()
	var vp: Vector2 = get_viewport().get_visible_rect().size
	if win.x <= 0 or win.y <= 0 or safe.size.x <= 0 or safe.size.y <= 0:
		return
	var sx: float = vp.x / float(win.x)
	var sy: float = vp.y / float(win.y)
	var l: float = clampf(float(safe.position.x) * sx, 0.0, 160.0)
	var t: float = clampf(float(safe.position.y) * sy, 0.0, 80.0)
	var r: float = clampf(float(win.x - (safe.position.x + safe.size.x)) * sx, 0.0, 160.0)
	var b: float = clampf(float(win.y - (safe.position.y + safe.size.y)) * sy, 0.0, 80.0)
	_touch.apply_safe_area(l, t, r, b)
	_hud.position = Vector2(l + 20.0, t + 12.0)


func _setup_environment() -> void:
	var sky_mat: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.04, 0.10, 0.28)
	sky_mat.sky_horizon_color = Color(1.0, 0.55, 0.36)
	sky_mat.sky_curve = 0.18
	sky_mat.ground_horizon_color = Color(0.70, 0.38, 0.30)
	sky_mat.ground_bottom_color = Color(0.05, 0.06, 0.09)
	sky_mat.ground_curve = 0.04
	sky_mat.sun_angle_max = 32.0
	sky_mat.sun_curve = 0.12
	sky_mat.use_debanding = true

	var sky: Sky = Sky.new()
	sky.sky_material = sky_mat

	_env = Environment.new()
	_env.background_mode = Environment.BG_SKY
	_env.sky = sky
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	_env.ambient_light_energy = 0.9
	_env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	_env.tonemap_mode = Environment.TONE_MAPPER_ACES
	_env.tonemap_exposure = 1.0
	_env.glow_enabled = true
	_env.glow_intensity = 0.8
	_env.glow_strength = 1.0
	_env.glow_bloom = 0.04
	_env.glow_hdr_threshold = 1.0
	_env.fog_enabled = true
	_env.fog_light_color = Color(0.92, 0.58, 0.46)
	_env.fog_density = 0.0008
	_env.fog_sky_affect = 0.35
	_env.fog_sun_scatter = 0.25
	_env.fog_aerial_perspective = 0.4
	_env.adjustment_enabled = true
	_env.adjustment_contrast = 1.06
	_env.adjustment_saturation = 1.12

	var we: WorldEnvironment = WorldEnvironment.new()
	we.environment = _env
	add_child(we)

	_sun = DirectionalLight3D.new()
	_sun.rotation_degrees = Vector3(-14.0, 40.0, 0.0)
	_sun.light_color = Color(1.0, 0.72, 0.5)
	_sun.light_energy = 2.3
	_sun.light_angular_distance = 1.0
	_sun.shadow_enabled = true
	_sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	_sun.directional_shadow_max_distance = 350.0
	_sun.shadow_bias = 0.05
	_sun.shadow_normal_bias = 1.0
	add_child(_sun)


func _setup_camera() -> void:
	_cam = Camera3D.new()
	_cam.fov = 68.0
	_cam.near = 0.4
	_cam.far = 7000.0
	add_child(_cam)
	_cam.make_current()


func _build_terrain() -> void:
	var mesh: ArrayMesh = Terrain.build_mesh(128)
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 0.92
	mat.metallic = 0.0
	_terrain_root = Node3D.new()
	add_child(_terrain_root)
	for iz in range(-1, 2):
		for ix in range(-1, 2):
			var mi: MeshInstance3D = MeshInstance3D.new()
			mi.mesh = mesh
			mi.material_override = mat
			mi.position = Vector3(float(ix) * Terrain.TILE, 0.0, float(iz) * Terrain.TILE)
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			_terrain_root.add_child(mi)


func _build_sea() -> void:
	var plane: PlaneMesh = PlaneMesh.new()
	plane.size = Vector2(9000.0, 9000.0)
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = Color(0.015, 0.11, 0.17)
	mat.roughness = 0.07
	mat.metallic = 0.15
	mat.metallic_specular = 0.9
	_sea = MeshInstance3D.new()
	_sea.mesh = plane
	_sea.material_override = mat
	_sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_sea)


func _find_city_site() -> Vector2:
	var offs: Array = [Vector2.ZERO]
	for ring_r in [260.0, 520.0]:
		for k in range(8):
			var ang: float = float(k) * TAU / 8.0
			offs.append(Vector2(cos(ang), sin(ang)) * float(ring_r))
	var best: Vector2 = Vector2.ZERO
	var best_score: float = -1.0e9
	var half: float = Terrain.TILE * 0.5
	var cx: float = -half
	while cx < half:
		var cz: float = -half
		while cz < half:
			var mn: float = 1.0e9
			var mx: float = -1.0e9
			for o in offs:
				var p: Vector2 = Vector2(cx, cz) + (o as Vector2)
				var hh: float = Terrain.height(p.x, p.y)
				mn = minf(mn, hh)
				mx = maxf(mx, hh)
			var score: float = mn - 0.25 * (mx - mn)
			if score > best_score:
				best_score = score
				best = Vector2(cx, cz)
			cz += 128.0
		cx += 128.0
	return best


func _build_ship() -> void:
	var parts: Dictionary = ShipBuilder.build()
	_ship = parts["root"] as Node3D
	_visual = parts["visual"] as Node3D
	_flames = parts["flames"] as Array
	_flame_mat = parts["flame_mat"] as StandardMaterial3D
	_nav_mats = parts["nav_mats"] as Array
	add_child(_ship)

	_yaw = deg_to_rad(160.0)
	_pitch = 0.0
	var fwd: Vector2 = Vector2(-sin(_yaw), -cos(_yaw))
	var start: Vector2 = _city_site - fwd * 650.0
	var ground: float = maxf(Terrain.height(start.x, start.y), 0.0)
	_ship.position = Vector3(start.x, ground + 170.0, start.y)
	_ship.rotation = Vector3(_pitch, _yaw, 0.0)

	# Put the camera right behind the ship so the first frame is already correct.
	var b: Basis = _ship.global_transform.basis
	_cam.global_position = _ship.global_position + b * Vector3(0.0, 4.5, 16.0)
	_cam.look_at(_ship.global_position + (-b.z) * 14.0, Vector3.UP)


func _build_city() -> void:
	_city_mm = MultiMesh.new()
	_city_mm.transform_format = MultiMesh.TRANSFORM_3D
	_city_mm.use_colors = true
	var box: BoxMesh = BoxMesh.new()
	box.size = Vector3.ONE
	_city_mm.mesh = box
	_city_mm.instance_count = CITY_MAX

	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = 20261018
	var spread: float = 3.16
	var golden: float = 2.39996323
	var radius_max: float = spread * sqrt(float(CITY_MAX))

	for i in range(CITY_MAX):
		var r: float = spread * sqrt(float(i) + 0.5)
		var a: float = float(i) * golden
		var x: float = _city_site.x + cos(a) * r
		var z: float = _city_site.y + sin(a) * r
		var ground: float = maxf(Terrain.height(x, z), 0.0)
		var k: float = 1.25 - 0.8 * (r / radius_max)
		var hgt: float = (5.0 + pow(rng.randf(), 2.4) * 85.0) * k
		var w: float = 2.4 + rng.randf() * 2.2
		var d: float = 2.4 + rng.randf() * 2.2
		var bs: Basis = Basis.from_scale(Vector3(w, hgt, d))
		_city_mm.set_instance_transform(i, Transform3D(bs, Vector3(x, ground - 3.0 + hgt * 0.5, z)))
		var hue: float = 0.56 + rng.randf() * 0.10
		var sat: float = 0.10 + rng.randf() * 0.25
		var val: float = 0.22 + rng.randf() * 0.50
		if rng.randf() < 0.08:
			hue = 0.07 + rng.randf() * 0.04
			sat = 0.35
			val = 0.70
		_city_mm.set_instance_color(i, Color.from_hsv(hue, sat, val))
		if i % 3000 == 2999:
			_set_loading("Building city... %d%%" % int(100.0 * float(i) / float(CITY_MAX)))
			await get_tree().process_frame

	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 0.55
	mat.metallic = 0.35
	_city = MultiMeshInstance3D.new()
	_city.multimesh = _city_mm
	_city.material_override = mat
	_city.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_city)


# ---------------------------------------------------------------- buttons

func _on_button(id: String) -> void:
	if id == "quality":
		_quality = (_quality + 1) % QUALITY.size()
		_apply_quality()
	elif id == "city_plus":
		_city_level = mini(_city_level + 1, CITY_LEVELS.size() - 1)
		_apply_city()
	elif id == "city_minus":
		_city_level = maxi(_city_level - 1, 0)
		_apply_city()


func _apply_quality() -> void:
	var q: Dictionary = QUALITY[_quality]
	var vp: Viewport = get_viewport()
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	vp.scaling_3d_scale = float(q["scale"])
	if bool(q["fxaa"]):
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
	else:
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
	_sun.shadow_enabled = bool(q["shadows"])
	_env.glow_enabled = bool(q["glow"])
	_touch.set_button_text("quality", "QUALITY: " + String(q["name"]))


func _apply_city() -> void:
	if _city_mm == null:
		return
	_city_mm.visible_instance_count = int(CITY_LEVELS[_city_level])


# ---------------------------------------------------------------- per frame

func _process(delta: float) -> void:
	if not _ready_done:
		return
	_time += delta
	_frame_ms[_frame_i] = delta * 1000.0
	_frame_i = (_frame_i + 1) % FRAME_SAMPLES
	var dt: float = minf(delta, 0.05)
	_update_flight(dt)
	_update_camera(dt)
	_update_follow()
	_animate_ship()
	_hud_t += delta
	if _hud_t >= 0.25:
		_hud_t = 0.0
		_update_hud()


func _update_flight(dt: float) -> void:
	var l: Vector2 = _touch.left_vec
	var r: Vector2 = _touch.right_vec

	# Left stick up/down changes cruise speed; it stays where you leave it.
	_target_speed = clampf(_target_speed - l.y * 140.0 * dt, 25.0, 260.0)
	var boost: float = 1.0
	if _touch.boost_held:
		boost = 1.7
	_speed = lerpf(_speed, _target_speed * boost, 1.0 - exp(-2.0 * dt))

	# Right stick aims: right = turn right, up = nose up.
	_yaw -= r.x * 1.25 * dt
	_pitch -= r.y * 1.0 * dt
	_pitch = clampf(_pitch, deg_to_rad(-70.0), deg_to_rad(70.0))
	var roll_target: float = -r.x * 0.9 - l.x * 0.3
	_roll = lerpf(_roll, roll_target, 1.0 - exp(-5.0 * dt))

	_ship.rotation = Vector3(_pitch, _yaw, 0.0)
	_visual.rotation = Vector3(0.0, 0.0, _roll)

	var b: Basis = _ship.global_transform.basis
	var vel: Vector3 = (-b.z) * _speed + b.x * (l.x * 40.0)
	var p: Vector3 = _ship.global_position + vel * dt

	var ground: float = maxf(Terrain.height(p.x, p.z), 0.0) + 6.0
	if p.y < ground:
		p.y = ground
	p.y = minf(p.y, 3000.0)
	_ship.global_position = p


func _update_camera(dt: float) -> void:
	var b: Basis = _ship.global_transform.basis
	var target: Vector3 = _ship.global_position + b * Vector3(0.0, 4.5, 16.0)
	var cp: Vector3 = _cam.global_position.lerp(target, 1.0 - exp(-8.0 * dt))
	var floor_y: float = maxf(Terrain.height(cp.x, cp.z), 0.0) + 3.0
	if cp.y < floor_y:
		cp.y = floor_y
	_cam.global_position = cp
	var look_at_pos: Vector3 = _ship.global_position + (-b.z) * 14.0
	if cp.distance_to(look_at_pos) > 0.5:
		_cam.look_at(look_at_pos, Vector3.UP)
	var fov_target: float = 68.0 + clampf(_speed / 260.0, 0.0, 1.8) * 14.0
	_cam.fov = lerpf(_cam.fov, fov_target, 1.0 - exp(-4.0 * dt))


func _update_follow() -> void:
	var p: Vector3 = _ship.global_position
	var snap_x: float = roundf(p.x / Terrain.TILE) * Terrain.TILE
	var snap_z: float = roundf(p.z / Terrain.TILE) * Terrain.TILE
	_terrain_root.position = Vector3(snap_x, 0.0, snap_z)
	_sea.position = Vector3(p.x, 0.0, p.z)


func _animate_ship() -> void:
	var ratio: float = clampf(_speed / 260.0, 0.0, 1.8)
	var flame_len: float = 0.8 + 2.4 * ratio
	for f in _flames:
		var n: Node3D = f as Node3D
		var flick: float = 1.0 + 0.08 * sin(_time * 47.0 + n.position.x * 3.0)
		n.scale = Vector3(flick, flick, flame_len * flick)
	if _flame_mat != null:
		var boost_amt: float = 0.0
		if _touch.boost_held:
			boost_amt = 1.0
		_flame_mat.albedo_color = Color(0.45 + 0.3 * boost_amt, 0.85, 1.0, 0.55 + 0.3 * boost_amt)
	# Blinking navigation lights (red left, green right).
	if _nav_mats.size() >= 2:
		var red_mat: StandardMaterial3D = _nav_mats[0] as StandardMaterial3D
		var green_mat: StandardMaterial3D = _nav_mats[1] as StandardMaterial3D
		var red_on: bool = fmod(_time, 1.2) < 0.15
		var green_on: bool = fmod(_time + 0.6, 1.2) < 0.15
		red_mat.emission_energy_multiplier = 8.0 if red_on else 0.3
		green_mat.emission_energy_multiplier = 8.0 if green_on else 0.3


func _update_hud() -> void:
	var sum: float = 0.0
	var worst: float = 0.0
	var count: int = 0
	for i in range(FRAME_SAMPLES):
		var v: float = _frame_ms[i]
		if v > 0.0:
			sum += v
			count += 1
			worst = maxf(worst, v)
	var avg: float = 0.0
	if count > 0:
		avg = sum / float(count)

	var method: String = "?"
	if RenderingServer.has_method("get_current_rendering_method"):
		method = str(RenderingServer.call("get_current_rendering_method"))
	var driver: String = "?"
	if RenderingServer.has_method("get_current_rendering_driver_name"):
		driver = str(RenderingServer.call("get_current_rendering_driver_name"))

	var win: Vector2i = DisplayServer.window_get_size()
	var q: Dictionary = QUALITY[_quality]
	var sc: float = float(q["scale"])
	var p: Vector3 = _ship.global_position
	var agl: float = p.y - maxf(Terrain.height(p.x, p.z), 0.0)

	var lines: PackedStringArray = PackedStringArray()
	lines.append("PORTAL DRIVE  step 1: pipeline + performance test")
	lines.append("FPS %d    frame %.1f ms avg / %.1f ms worst" % [int(Engine.get_frames_per_second()), avg, worst])
	lines.append("Speed %d m/s    Altitude %d m" % [int(_speed), int(agl)])
	lines.append("Quality %s    3D scale %.2f  (%d x %d)" % [String(q["name"]), sc, int(float(win.x) * sc), int(float(win.y) * sc)])
	lines.append("City boxes %d    Draw calls %d    Tris %dk" % [int(CITY_LEVELS[_city_level]), int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)), int(Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME) / 1000.0)])
	lines.append("Renderer %s / %s    VRAM %d MB" % [method, driver, int(Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED) / 1048576.0)])
	lines.append("GPU: %s" % RenderingServer.get_video_adapter_name())
	lines.append("Device: %s    %s %s    Godot %s" % [OS.get_model_name(), OS.get_name(), OS.get_version(), String(Engine.get_version_info()["string"])])
	_hud.text = "\n".join(lines)
