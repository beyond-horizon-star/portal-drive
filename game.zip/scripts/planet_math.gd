extends RefCounted
## Planet maths shared by the game code (GENERATED FILE - the terrain function below is
## the same one that is embedded in shaders/planet_terrain.gdshader).
## The planet is a sphere of radius R centred on the world origin.

const R: float = 16000.0
const FACE_ARC: float = 25132.741228718
const SURFACE_GRAVITY: float = 20.0
const SPACE_START: float = 700.0     # sky starts to darken
const SPACE_FULL: float = 2600.0     # sky is fully black space
const ATM_TOP: float = 3600.0        # visible top of the atmosphere (glow shell)
const BEND_MIN: float = 0.2          # near the ground the planet is DISPLAYED 5x flatter
const START_DIR: Vector3 = Vector3(-0.913676744, 0.026055222, -0.405605638)
const START_HEADING: Vector3 = Vector3(0.419608157, 0.258684781, -0.870063893)

## Showcase places (the SITES button flies you there).
const SITES: Array = [
	{"name": "WATERFALL A", "dir": Vector3(-0.913676744, 0.026055222, -0.405605638), "heading": Vector3(0.419608157, 0.258684781, -0.870063893), "alt": 70.0},
	{"name": "WATERFALL B", "dir": Vector3(-0.921785077, 0.252133605, -0.294518111), "heading": Vector3(-0.289141076, -0.940057729, 0.180800731), "alt": 70.0},
	{"name": "WATERFALL C", "dir": Vector3(-0.935311332, 0.216163169, -0.280118184), "heading": Vector3(-0.32953265, -0.489422799, 0.807386869), "alt": 70.0},
	{"name": "CITY", "dir": Vector3(-0.337806172, 0.9192675, -0.202074871), "heading": Vector3(-0.752215689, -0.134630556, 0.645016411), "alt": 260.0},
	{"name": "DESERT", "dir": Vector3(0.80998708, -0.5633725, -0.162887558), "heading": Vector3(-0.509689163, -0.813651137, 0.279622573), "alt": 120.0},
	{"name": "MOUNTAINS", "dir": Vector3(0.08199582, -0.4596425, 0.884310725), "heading": Vector3(0.973232235, -0.154217647, -0.170399336), "alt": 280.0},
	{"name": "FOREST", "dir": Vector3(-0.375925252, 0.3224225, -0.868748488), "heading": Vector3(-0.434215482, -0.889509149, -0.14223357), "alt": 110.0},
	{"name": "OPEN SEA", "dir": Vector3(0.56634461, -0.0540225, -0.822396104), "heading": Vector3(0.82359879, -0.0, 0.567172842), "alt": 55.0},
]

const FACE_N: Array = [Vector3(1, 0, 0), Vector3(-1, 0, 0), Vector3(0, 1, 0), Vector3(0, -1, 0), Vector3(0, 0, 1), Vector3(0, 0, -1)]
const FACE_S: Array = [Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(1, 0, 0), Vector3(1, 0, 0), Vector3(-1, 0, 0)]
const FACE_T: Array = [Vector3(0, 1, 0), Vector3(0, 1, 0), Vector3(0, 0, -1), Vector3(0, 0, 1), Vector3(0, 1, 0), Vector3(0, 1, 0)]


## Full-detail terrain sample for a unit direction. Returns
## [geo, wdepth, water_level, desert, forest, city, river, mount, rgx, rgy, rgz, cgx, cgy, cgz, fstep, fmask]
## geo = ground height incl. sea/river water surface (m above sea level).
static func sample_dir(dx: float, dy: float, dz: float) -> PackedFloat32Array:
	var px: float = dx * R
	var py: float = dy * R
	var pz: float = dz * R
	var cont: float = 1.0*sin((0.000114787)*px + (-0.000122358)*py + (7.748e-05)*pz + 4.406253221) + 0.8*sin((0.000127963)*px + (0.000195386)*py + (-6.2048e-05)*pz + 2.71038644) + 0.6*sin((-7.511e-06)*px + (-0.000279376)*py + (0.000106832)*pz + 5.003408183) + 0.45*sin((0.000227005)*px + (-0.000188199)*py + (0.000222831)*pz + 5.942117237) + 0.35*sin((-6.833e-05)*px + (0.000291683)*py + (0.000334174)*pz + 5.005029972)
	var base: float = 125.0*cont + (-52.0)
	var cgx: float = 0.014348406*cos((0.000114787)*px + (-0.000122358)*py + (7.748e-05)*pz + 4.406253221) + 0.012796318*cos((0.000127963)*px + (0.000195386)*py + (-6.2048e-05)*pz + 2.71038644) + -0.000563321*cos((-7.511e-06)*px + (-0.000279376)*py + (0.000106832)*pz + 5.003408183) + 0.012769038*cos((0.000227005)*px + (-0.000188199)*py + (0.000222831)*pz + 5.942117237) + -0.002989459*cos((-6.833e-05)*px + (0.000291683)*py + (0.000334174)*pz + 5.005029972)
	var cgy: float = -0.015294792*cos((0.000114787)*px + (-0.000122358)*py + (7.748e-05)*pz + 4.406253221) + 0.019538554*cos((0.000127963)*px + (0.000195386)*py + (-6.2048e-05)*pz + 2.71038644) + -0.020953166*cos((-7.511e-06)*px + (-0.000279376)*py + (0.000106832)*pz + 5.003408183) + -0.010586176*cos((0.000227005)*px + (-0.000188199)*py + (0.000222831)*pz + 5.942117237) + 0.012761127*cos((-6.833e-05)*px + (0.000291683)*py + (0.000334174)*pz + 5.005029972)
	var cgz: float = 0.009685045*cos((0.000114787)*px + (-0.000122358)*py + (7.748e-05)*pz + 4.406253221) + -0.00620479*cos((0.000127963)*px + (0.000195386)*py + (-6.2048e-05)*pz + 2.71038644) + 0.008012411*cos((-7.511e-06)*px + (-0.000279376)*py + (0.000106832)*pz + 5.003408183) + 0.012534217*cos((0.000227005)*px + (-0.000188199)*py + (0.000222831)*pz + 5.942117237) + 0.01462013*cos((-6.833e-05)*px + (0.000291683)*py + (0.000334174)*pz + 5.005029972)
	var mm0: float = 0.5 + 0.5*sin((0.00035558)*px + (-5.0557e-05)*py + (-0.000381002)*pz + 5.133700409)
	var mm1: float = 0.5 + 0.5*sin((7.054e-06)*px + (-2.6311e-05)*py + (-0.000404451)*pz + 6.213977387)
	var mmask: float = smoothstep(0.10, 0.55, mm0*mm1)
	var rd0: float = 1.0 - absf(sin((-0.001027241)*px + (0.001286498)*py + (0.001070052)*pz + 0.47317353 + 1.8*sin((0.001181286)*px + (0.002188013)*py + (-0.001664087)*pz + 2.55587259)))
	var rd1: float = 1.0 - absf(sin((-0.000523199)*px + (-0.001029731)*py + (0.000729127)*pz + 2.936613424 + 1.5*sin((0.000533895)*px + (-0.000747506)*py + (-0.001962248)*pz + 0.600735119)))
	var rd2: float = 1.0 - absf(sin((-0.005444875)*px + (-0.002620854)*py + (-0.003496176)*pz + 6.205902475 + 1.2*sin((0.00309617)*px + (-0.012665581)*py + (0.010879839)*pz + 3.570274354)))
	var ridge: float = pow(maxf(rd0*rd1, 0.0), 0.7)*0.8 + 0.2*rd2*rd0
	var landmask: float = smoothstep(0.0, 80.0, base)
	var mount: float = 900.0*mmask*ridge*landmask
	var cm0: float = 0.5 + 0.5*sin((0.000170548)*px + (0.000485167)*py + (0.000472138)*pz + 3.184374515)
	var cm1: float = 0.5 + 0.5*sin((0.000540986)*px + (-2.9145e-05)*py + (7.0696e-05)*pz + 4.714053308)
	var cmask: float = smoothstep(0.76, 0.92, cm0*cm1)
	var cityok: float = smoothstep(12.0, 35.0, base)*(1.0 - smoothstep(110.0, 200.0, base))
	var city0: float = cmask*cityok
	var ds0: float = 0.5 + 0.5*sin((-1.3145e-05)*px + (-0.000189799)*py + (0.000149009)*pz + 0.401543495)
	var ds1: float = 0.5 + 0.5*sin((-5.9064e-05)*px + (-0.00010287)*py + (-0.000141704)*pz + 1.81135834)
	var dmask: float = smoothstep(0.56, 0.74, ds0*0.6 + ds1*0.4)
	var lat: float = absf(py)/16000.0
	var desert: float = dmask*(1.0 - smoothstep(0.60, 0.85, lat))*smoothstep(6.0, 25.0, base)*(1.0 - smoothstep(260.0, 420.0, base))*(1.0 - city0)
	var fq: float = sin((-0.000216423)*px + (-0.001576538)*py + (0.000939561)*pz + 0.477371469 + 1.8*sin((0.000464632)*px + (-0.003182952)*py + (-0.00076732)*pz + 1.120905997))
	var fm: float = 0.5 + 0.5*sin((0.000234865)*px + (0.000611489)*py + (9.1398e-05)*pz + 2.918741195)
	var fstep: float = smoothstep(-0.004, 0.004, fq)
	var fmask: float = smoothstep(0.30, 0.55, fm)*smoothstep(12.0, 60.0, base)*(1.0 - smoothstep(260.0, 420.0, base))*(1.0 - city0)
	var fq2: float = sin((0.001665949)*px + (-0.001271619)*py + (-0.000549385)*pz + 1.310606084 + 1.6*sin((0.0007579)*px + (-0.001531449)*py + (-0.003535747)*pz + 0.772293393))
	var fm2: float = 0.5 + 0.5*sin((-0.000308736)*px + (-0.000388289)*py + (0.000283163)*pz + 4.760471674)
	var fstep2: float = smoothstep(-0.004, 0.004, fq2)
	var fmask2: float = smoothstep(0.30, 0.55, fm2)*smoothstep(12.0, 60.0, base)*(1.0 - smoothstep(260.0, 420.0, base))*(1.0 - city0)
	var fallh: float = 38.0*fstep*fmask + 30.0*fstep2*fmask2
	var hA: float = 60.0*sin((0.001943294)*px + (0.000262008)*py + (0.000735833)*pz + 2.129220519 + 1.5*sin((-0.00032309)*px + (0.000734998)*py + (-0.000341957)*pz + 4.300218682)) + 45.0*sin((-0.000614355)*px + (-0.001511153)*py + (0.002684882)*pz + 1.959023762 + 1.5*sin((-0.000467258)*px + (0.001159938)*py + (0.000386895)*pz + 3.347646204)) + 34.0*sin((0.000409107)*px + (0.000133617)*py + (-0.004467307)*pz + 2.044540152 + 1.5*sin((-0.001028935)*px + (-0.00077063)*py + (0.001358052)*pz + 4.936823346))
	var hB: float = 24.0*sin((-0.005171979)*px + (-0.003646415)*py + (0.001922938)*pz + 0.317955142 + 1.5*sin((-0.000256608)*px + (-0.000660832)*py + (0.002663042)*pz + 5.709449544))
	var hC: float = 16.0*sin((0.000761422)*px + (0.005964752)*py + (0.007760465)*pz + 0.323353317 + 1.5*sin((0.002273995)*px + (0.00250158)*py + (-0.00230308)*pz + 2.494205288)) + 11.0*sin((-0.01145264)*px + (0.008031093)*py + (0.005304633)*pz + 0.270797379 + 1.5*sin((0.000720402)*px + (-0.006054241)*py + (0.001296706)*pz + 5.803032256))
	var hD: float = 7.0*sin((0.008749299)*px + (-0.013976737)*py + (-0.015220112)*pz + 2.487512234 + 1.5*sin((0.007837699)*px + (-0.004242026)*py + (0.002828035)*pz + 0.934114508))
	var hills: float = hA + hB + hC + hD
	var dA: float = 6.0*sin((-0.024627498)*px + (-0.016083131)*py + (-0.015113047)*pz + 3.761625084 + 1.3*sin((0.001652478)*px + (0.012671366)*py + (-0.005154056)*pz + 5.99859242)) + 4.0*sin((0.036579727)*px + (-0.018170425)*py + (-0.032761502)*pz + 5.811986306 + 1.3*sin((-0.019257938)*px + (0.008687286)*py + (-0.005443126)*pz + 5.774851978))
	var dB: float = 2.6*sin((-0.031358377)*px + (-0.07400419)*py + (0.005378089)*pz + 4.481432743 + 1.3*sin((0.019540922)*px + (-0.006557257)*py + (-0.026489591)*pz + 1.395354452)) + 1.7*sin((-0.078774044)*px + (0.087469141)*py + (-0.027272804)*pz + 2.550516815 + 1.3*sin((-0.027624855)*px + (-0.038525583)*py + (-0.016951998)*pz + 5.365767487)) + 1.0*sin((0.063542672)*px + (0.061325524)*py + (-0.150543186)*pz + 3.094825621 + 1.3*sin((0.067186352)*px + (-0.002397139)*py + (-0.027726246)*pz + 6.059083855))
	var detail: float = dA + dB
	var du1: float = 0.5 + 0.5*sin(((-0.007231624)*px + (-0.014289615)*py + (-0.033309844)*pz) + 2.2*sin((0.005463579)*px + (-0.002302722)*py + (0.00368586)*pz + 0.638745177) + 5.476867889)
	var du2: float = 0.5 + 0.5*sin(((-0.075569423)*px + (0.02654086)*py + (0.024560749)*pz) + 1.3*sin((-0.0035735)*px + (-0.009591904)*py + (0.010909905)*pz + 2.00640621) + 2.620816123)
	var dune: float = desert*(15.0*du1*du1 + 6.0*du2)
	var land: float = base + fallh + mount*(1.0 - city0) + hills*(1.0 - 0.85*city0)*(1.0 - 0.6*desert) + detail*(1.0 - city0) + dune
	var lowA: float = base + fallh + 0.55*mount + hA
	var rw0: float = 1.6*sin((-0.001085426)*px + (0.001358662)*py + (-0.000445663)*pz + 2.328449151)
	var ra0: float = (-0.000185505)*px + (0.000206945)*py + (6.5793e-05)*pz + 3.683510967 + rw0
	var rw1: float = 1.3*sin((-0.000103452)*px + (0.000733814)*py + (-0.000954366)*pz + 0.258940671)
	var ra1: float = (-7.1436e-05)*px + (-0.000101497)*py + (0.000168702)*pz + 4.545367326 + rw1
	var rw2: float = 1.1*sin((-0.000598313)*px + (-0.000664658)*py + (-7.7032e-05)*pz + 1.139290286)
	var ra2: float = (0.000127513)*px + (-0.000103667)*py + (1.8255e-05)*pz + 4.678506074 + rw2
	var rn: float = 1.0*sin(ra0) + 0.8*sin(ra1) + 0.6*sin(ra2)
	var rc0: float = 1.0*cos(ra0)
	var rq0: float = 1.6*cos((-0.001085426)*px + (0.001358662)*py + (-0.000445663)*pz + 2.328449151)
	var rc1: float = 0.8*cos(ra1)
	var rq1: float = 1.3*cos((-0.000103452)*px + (0.000733814)*py + (-0.000954366)*pz + 0.258940671)
	var rc2: float = 0.6*cos(ra2)
	var rq2: float = 1.1*cos((-0.000598313)*px + (-0.000664658)*py + (-7.7032e-05)*pz + 1.139290286)
	var rgx: float = rc0*((-0.000185505) + rq0*(-0.001085426)) + rc1*((-7.1436e-05) + rq1*(-0.000103452)) + rc2*((0.000127513) + rq2*(-0.000598313))
	var rgy: float = rc0*((0.000206945) + rq0*(0.001358662)) + rc1*((-0.000101497) + rq1*(0.000733814)) + rc2*((-0.000103667) + rq2*(-0.000664658))
	var rgz: float = rc0*((6.5793e-05) + rq0*(-0.000445663)) + rc1*((0.000168702) + rq1*(-0.000954366)) + rc2*((1.8255e-05) + rq2*(-7.7032e-05))
	var rglen: float = sqrt(rgx*rgx + rgy*rgy + rgz*rgz)
	var rdist: float = absf(rn)/maxf(rglen, 0.0002)
	var rhw: float = 55.0 + 28.0*(0.5 + 0.5*sin((0.000166902)*px + (0.000116191)*py + (5.008e-05)*pz + 3.392356815))
	var prof0: float = 1.0 - smoothstep(rhw*0.35, rhw*1.25, rdist)
	var hgx: float = 60.0*cos((0.001943294)*px + (0.000262008)*py + (0.000735833)*pz + 2.129220519 + 1.5*sin((-0.00032309)*px + (0.000734998)*py + (-0.000341957)*pz + 4.300218682))*((0.001943294) + 1.5*cos((-0.00032309)*px + (0.000734998)*py + (-0.000341957)*pz + 4.300218682)*(-0.00032309)) + 45.0*cos((-0.000614355)*px + (-0.001511153)*py + (0.002684882)*pz + 1.959023762 + 1.5*sin((-0.000467258)*px + (0.001159938)*py + (0.000386895)*pz + 3.347646204))*((-0.000614355) + 1.5*cos((-0.000467258)*px + (0.001159938)*py + (0.000386895)*pz + 3.347646204)*(-0.000467258)) + 34.0*cos((0.000409107)*px + (0.000133617)*py + (-0.004467307)*pz + 2.044540152 + 1.5*sin((-0.001028935)*px + (-0.00077063)*py + (0.001358052)*pz + 4.936823346))*((0.000409107) + 1.5*cos((-0.001028935)*px + (-0.00077063)*py + (0.001358052)*pz + 4.936823346)*(-0.001028935))
	var hgy: float = 60.0*cos((0.001943294)*px + (0.000262008)*py + (0.000735833)*pz + 2.129220519 + 1.5*sin((-0.00032309)*px + (0.000734998)*py + (-0.000341957)*pz + 4.300218682))*((0.000262008) + 1.5*cos((-0.00032309)*px + (0.000734998)*py + (-0.000341957)*pz + 4.300218682)*(0.000734998)) + 45.0*cos((-0.000614355)*px + (-0.001511153)*py + (0.002684882)*pz + 1.959023762 + 1.5*sin((-0.000467258)*px + (0.001159938)*py + (0.000386895)*pz + 3.347646204))*((-0.001511153) + 1.5*cos((-0.000467258)*px + (0.001159938)*py + (0.000386895)*pz + 3.347646204)*(0.001159938)) + 34.0*cos((0.000409107)*px + (0.000133617)*py + (-0.004467307)*pz + 2.044540152 + 1.5*sin((-0.001028935)*px + (-0.00077063)*py + (0.001358052)*pz + 4.936823346))*((0.000133617) + 1.5*cos((-0.001028935)*px + (-0.00077063)*py + (0.001358052)*pz + 4.936823346)*(-0.00077063))
	var hgz: float = 60.0*cos((0.001943294)*px + (0.000262008)*py + (0.000735833)*pz + 2.129220519 + 1.5*sin((-0.00032309)*px + (0.000734998)*py + (-0.000341957)*pz + 4.300218682))*((0.000735833) + 1.5*cos((-0.00032309)*px + (0.000734998)*py + (-0.000341957)*pz + 4.300218682)*(-0.000341957)) + 45.0*cos((-0.000614355)*px + (-0.001511153)*py + (0.002684882)*pz + 1.959023762 + 1.5*sin((-0.000467258)*px + (0.001159938)*py + (0.000386895)*pz + 3.347646204))*((0.002684882) + 1.5*cos((-0.000467258)*px + (0.001159938)*py + (0.000386895)*pz + 3.347646204)*(0.000386895)) + 34.0*cos((0.000409107)*px + (0.000133617)*py + (-0.004467307)*pz + 2.044540152 + 1.5*sin((-0.001028935)*px + (-0.00077063)*py + (0.001358052)*pz + 4.936823346))*((-0.004467307) + 1.5*cos((-0.001028935)*px + (-0.00077063)*py + (0.001358052)*pz + 4.936823346)*(0.001358052))
	var gtx: float = cgx + hgx
	var gty: float = cgy + hgy
	var gtz: float = cgz + hgz
	var gdot: float = (gtx*px + gty*py + gtz*pz)/16000.0
	var slopeb: float = sqrt(maxf(gtx*gtx + gty*gty + gtz*gtz - gdot*gdot, 0.0))
	var sbuf: float = minf(380.0*slopeb, 90.0)
	var wlr: float = maxf(lowA - 30.0 - sbuf, 0.6)
	var lowland: float = (1.0 - smoothstep(110.0, 260.0, base))*(1.0 - smoothstep(60.0, 160.0, mount))
	var coast: float = smoothstep(3.0, 14.0, land)
	var prof: float = prof0*lowland*coast
	var vmask: float = (1.0 - smoothstep(rhw*1.2, rhw*7.0, rdist))*lowland*coast
	var vfloor: float = wlr + 3.0 + 0.10*maxf(hills + detail + dune, 0.0)
	var land2: float = minf(land, lerpf(land, vfloor, vmask))
	var bed: float = wlr - 7.0
	var hfa: float = lerpf(land2, bed, prof)
	var hf: float = maxf(hfa, 0.0) + maxf(minf(hfa, 0.0), -420.0)*0.6
	var hasr: float = smoothstep(0.12, 0.30, prof)
	var wl: float = maxf(hasr*wlr, 0.0)
	var geo: float = maxf(hf, wl)
	var wdepth: float = maxf(wl - hf, 0.0)
	var fs0: float = 0.5 + 0.5*sin((-0.000417975)*px + (0.000386516)*py + (-0.001065788)*pz + 0.468738661)
	var fs1: float = 0.5 + 0.5*sin((-0.000304995)*px + (0.000718844)*py + (8.4208e-05)*pz + 0.95388014)
	var forest: float = smoothstep(0.30, 0.50, fs0*0.55 + fs1*0.45)*(1.0 - desert)*smoothstep(8.0, 30.0, land)*(1.0 - smoothstep(380.0, 520.0, land))*(1.0 - city0)*(1.0 - prof)*(1.0 - smoothstep(0.78, 0.92, lat))
	return PackedFloat32Array([geo, wdepth, wl, desert, forest, city0, prof, mount, rgx, rgy, rgz, cgx, cgy, cgz, fstep, fmask])


## Ground height (m above sea level) for a unit direction; water surfaces count as ground.
static func height_dir(d: Vector3) -> float:
	return sample_dir(d.x, d.y, d.z)[0]


static func height_pos(pos: Vector3) -> float:
	return height_dir(pos.normalized())


## Direction on the unit sphere for a point (a, b) in -1..1 on cube face f.
static func face_dir(f: int, a: float, b: float) -> Vector3:
	var p: Vector3 = FACE_N[f] + FACE_S[f] * a + FACE_T[f] * b
	var x2: float = p.x * p.x
	var y2: float = p.y * p.y
	var z2: float = p.z * p.z
	var x: float = p.x * sqrt(1.0 - 0.5 * (y2 + z2) + y2 * z2 / 3.0)
	var y: float = p.y * sqrt(1.0 - 0.5 * (z2 + x2) + z2 * x2 / 3.0)
	var z: float = p.z * sqrt(1.0 - 0.5 * (x2 + y2) + x2 * y2 / 3.0)
	return Vector3(x, y, z).normalized()


static func gravity_at(r: float) -> float:
	var k: float = R / maxf(r, R * 0.5)
	return SURFACE_GRAVITY * k * k


## 0 inside the atmosphere, 1 in space (smooth between SPACE_START and SPACE_FULL).
static func space_amount(altitude: float) -> float:
	return smoothstep(SPACE_START, SPACE_FULL, altitude)


## 1/curvature-scale used by the terrain shader: near the ground the planet is drawn flatter.
static func bend_inv_for(altitude: float) -> float:
	return lerpf(BEND_MIN, 1.0, smoothstep(150.0, 3000.0, altitude))
