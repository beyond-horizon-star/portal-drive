extends Node3D
## The planet: a cube-sphere quadtree. Every patch is the same 16x16 grid mesh drawn
## through ONE MultiMesh; the shader turns (face, a0, b0, size) into a piece of the
## sphere and computes terrain, rivers and ocean on the GPU. No meshes are generated at run time.
## Near the ground the shader DISPLAYS the planet with a flatter curvature ("bend");
## the real sphere, distances and physics are unchanged and the bend fades out with altitude.

const PlanetMath = preload("res://scripts/planet_math.gd")

const GRID: int = 16
const MAX_PATCHES: int = 900
const MAX_DEPTH: int = 8
const SPLIT_K: float = 1.7
const MAX_VIEW: float = 14000.0
const STRIDE: int = 16

var patch_count: int = 0

var _mm: MultiMesh = null
var _mat: ShaderMaterial = null
var _buf: PackedFloat32Array = PackedFloat32Array()
var _count: int = 0
var _cam_pos: Vector3 = Vector3.ZERO
var _cam_dir: Vector3 = Vector3.UP
var _cam_fwd: Vector3 = Vector3.FORWARD
var _theta_vis: float = 1.0
var _altitude: float = 0.0


func _ready() -> void:
	_mm = MultiMesh.new()
	_mm.transform_format = MultiMesh.TRANSFORM_3D
	_mm.use_custom_data = true
	_mm.mesh = _build_patch_mesh(GRID)
	_mm.instance_count = MAX_PATCHES
	_mm.visible_instance_count = 0
	_mm.custom_aabb = AABB(Vector3(-60000.0, -60000.0, -60000.0), Vector3(120000.0, 120000.0, 120000.0))

	_buf.resize(MAX_PATCHES * STRIDE)
	for i in range(MAX_PATCHES):
		var base: int = i * STRIDE
		_buf[base] = 1.0
		_buf[base + 5] = 1.0
		_buf[base + 10] = 1.0

	_mat = ShaderMaterial.new()
	_mat.shader = load("res://shaders/planet_terrain.gdshader") as Shader

	var mmi: MultiMeshInstance3D = MultiMeshInstance3D.new()
	mmi.multimesh = _mm
	mmi.material_override = _mat
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mmi.extra_cull_margin = 100000.0
	add_child(mmi)


## One flat grid in (0..1, 0, 0..1) plus a skirt (vertices with y = -1) on every edge
## that the shader pulls down to hide cracks between different levels of detail.
func _build_patch_mesh(n: int) -> ArrayMesh:
	var verts: PackedVector3Array = PackedVector3Array()
	var idx: PackedInt32Array = PackedInt32Array()
	var fn: float = float(n)
	for j in range(n + 1):
		for i in range(n + 1):
			verts.append(Vector3(float(i) / fn, 0.0, float(j) / fn))
	for j in range(n):
		for i in range(n):
			var a: int = j * (n + 1) + i
			var b: int = a + 1
			var c: int = a + (n + 1)
			var d: int = c + 1
			idx.append(a)
			idx.append(b)
			idx.append(c)
			idx.append(b)
			idx.append(d)
			idx.append(c)
	var edges: Array = []
	var e0: Array = []
	var e1: Array = []
	var e2: Array = []
	var e3: Array = []
	for i in range(n + 1):
		e0.append(i)
		e1.append(n * (n + 1) + i)
		e2.append(i * (n + 1))
		e3.append(i * (n + 1) + n)
	edges.append(e0)
	edges.append(e1)
	edges.append(e2)
	edges.append(e3)
	for edge in edges:
		var base_index: int = verts.size()
		for k in range(edge.size()):
			var v: Vector3 = verts[int(edge[k])]
			verts.append(Vector3(v.x, -1.0, v.z))
		for k in range(edge.size() - 1):
			var b0: int = int(edge[k])
			var b1: int = int(edge[k + 1])
			var s0: int = base_index + k
			var s1: int = base_index + k + 1
			idx.append(b0)
			idx.append(b1)
			idx.append(s0)
			idx.append(b1)
			idx.append(s1)
			idx.append(s0)

	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh: ArrayMesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.custom_aabb = AABB(Vector3(-60000.0, -60000.0, -60000.0), Vector3(120000.0, 120000.0, 120000.0))
	return mesh


## Call EVERY frame: keeps the display bend centred under the camera.
func update_bend(cam_pos: Vector3, night_amt: float) -> void:
	var rc: float = maxf(cam_pos.length(), 1.0)
	_altitude = rc - PlanetMath.R
	_mat.set_shader_parameter("bend_c", cam_pos / rc)
	_mat.set_shader_parameter("bend_inv", PlanetMath.bend_inv_for(_altitude))
	_mat.set_shader_parameter("night_amt", night_amt)


## Re-select the visible patches (call every few frames).
func update_view(cam_pos: Vector3, cam_fwd: Vector3) -> void:
	_cam_pos = cam_pos
	_cam_fwd = cam_fwd
	var rc: float = maxf(cam_pos.length(), 1.0)
	_cam_dir = cam_pos / rc
	_altitude = rc - PlanetMath.R
	var binv: float = PlanetMath.bend_inv_for(_altitude)
	var rd: float = PlanetMath.R / binv
	var s_h: float = rd * acos(clampf(rd / (rd + maxf(_altitude, 0.0)), 0.0, 1.0))
	var s_p: float = rd * acos(rd / (rd + 1200.0))
	_theta_vis = minf((s_h + s_p) / PlanetMath.R, PI)
	_count = 0
	for f in range(6):
		_visit(f, -1.0, -1.0, 2.0, 0)
	_mm.buffer = _buf
	_mm.visible_instance_count = _count
	patch_count = _count


func _visit(f: int, a0: float, b0: float, size: float, depth: int) -> void:
	if _count >= MAX_PATCHES:
		return
	var cdir: Vector3 = PlanetMath.face_dir(f, a0 + size * 0.5, b0 + size * 0.5)
	var edge: float = size * 0.5 * PlanetMath.FACE_ARC
	var rad: float = edge * 0.8 + 700.0

	# Hidden behind the horizon?
	var limit: float = minf(_theta_vis + rad / PlanetMath.R, PI)
	if _cam_dir.dot(cdir) < cos(limit):
		return
	var to_c: Vector3 = cdir * PlanetMath.R - _cam_pos
	var dist: float = to_c.length()
	# Behind the camera or far outside the view?
	var along: float = to_c.dot(_cam_fwd)
	if along < -rad:
		return
	if dist > rad:
		var ang_lim: float = minf(PI, 1.3 + asin(minf(1.0, rad / dist)))
		if along / dist < cos(ang_lim):
			return
	# Too far to be seen through the haze (only inside the atmosphere).
	if _altitude < PlanetMath.SPACE_FULL and dist - rad > MAX_VIEW:
		return

	if depth < MAX_DEPTH and dist - edge * 0.3 < edge * SPLIT_K:
		var h: float = size * 0.5
		_visit(f, a0, b0, h, depth + 1)
		_visit(f, a0 + h, b0, h, depth + 1)
		_visit(f, a0, b0 + h, h, depth + 1)
		_visit(f, a0 + h, b0 + h, h, depth + 1)
		return

	var base: int = _count * STRIDE
	_buf[base + 12] = float(f)
	_buf[base + 13] = a0
	_buf[base + 14] = b0
	_buf[base + 15] = size
	_count += 1
