extends Control
## Multi-touch controls: two floating sticks (left = speed/strafe, right = aim)
## and buttons. Everything is drawn in code; touches are tracked per finger.

signal button_pressed(id: String)

const STICK_R: float = 95.0
const DEAD: float = 0.10

# Stick values use screen axes: x right = +, y down = +. Range -1..1.
var left_vec: Vector2 = Vector2.ZERO
var right_vec: Vector2 = Vector2.ZERO
var boost_held: bool = false

var _left_idx: int = -1
var _left_origin: Vector2 = Vector2.ZERO
var _left_pos: Vector2 = Vector2.ZERO
var _right_idx: int = -1
var _right_origin: Vector2 = Vector2.ZERO
var _right_pos: Vector2 = Vector2.ZERO

var _buttons: Array = []
var _font: Font = null
var _safe_l: float = 0.0
var _safe_t: float = 0.0
var _safe_r: float = 0.0
var _safe_b: float = 0.0
var _texts: Dictionary = {}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_font = ThemeDB.fallback_font
	resized.connect(_layout)
	_layout()


func apply_safe_area(l: float, t: float, r: float, b: float) -> void:
	_safe_l = l
	_safe_t = t
	_safe_r = r
	_safe_b = b
	_layout()


func set_button_text(id: String, text: String) -> void:
	_texts[id] = text
	for b in _buttons:
		if String(b["id"]) == id:
			b["text"] = text
	queue_redraw()


func _text_for(id: String, fallback: String) -> String:
	if _texts.has(id):
		return String(_texts[id])
	return fallback


func _layout() -> void:
	_buttons.clear()
	var w: float = size.x
	var h: float = size.y
	var br: float = 64.0
	_buttons.append({
		"id": "boost",
		"text": _text_for("boost", "BOOST"),
		"rect": Rect2(_safe_l + 28.0, h * 0.42 - br, br * 2.0, br * 2.0),
		"round": true,
		"touch": -1,
	})
	var bw: float = 170.0
	var bh: float = 46.0
	var gap: float = 10.0
	var total: float = bw * 3.0 + gap * 2.0
	var x0: float = (w - total) * 0.5
	var y0: float = _safe_t + 10.0
	var ids: Array = ["quality", "city_minus", "city_plus"]
	var defaults: Array = ["QUALITY", "CITY -", "CITY +"]
	for i in range(3):
		var id: String = String(ids[i])
		_buttons.append({
			"id": id,
			"text": _text_for(id, String(defaults[i])),
			"rect": Rect2(x0 + float(i) * (bw + gap), y0, bw, bh),
			"round": false,
			"touch": -1,
		})
	queue_redraw()


func _hit(b: Dictionary, p: Vector2) -> bool:
	var r: Rect2 = b["rect"]
	if bool(b["round"]):
		return p.distance_to(r.get_center()) <= r.size.x * 0.5 + 10.0
	return r.grow(8.0).has_point(p)


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event as InputEventScreenTouch
		if t.pressed:
			_down(t.index, t.position)
		else:
			_up(t.index)
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event as InputEventScreenDrag
		_move(d.index, d.position)


func _down(idx: int, pos: Vector2) -> void:
	for b in _buttons:
		if int(b["touch"]) == -1 and _hit(b, pos):
			b["touch"] = idx
			if String(b["id"]) == "boost":
				boost_held = true
			else:
				button_pressed.emit(String(b["id"]))
			queue_redraw()
			return
	if pos.x < size.x * 0.5:
		if _left_idx == -1:
			_left_idx = idx
			_left_origin = pos
			_left_pos = pos
			left_vec = Vector2.ZERO
	else:
		if _right_idx == -1:
			_right_idx = idx
			_right_origin = pos
			_right_pos = pos
			right_vec = Vector2.ZERO
	queue_redraw()


func _up(idx: int) -> void:
	for b in _buttons:
		if int(b["touch"]) == idx:
			b["touch"] = -1
			if String(b["id"]) == "boost":
				boost_held = false
	if idx == _left_idx:
		_left_idx = -1
		left_vec = Vector2.ZERO
	if idx == _right_idx:
		_right_idx = -1
		right_vec = Vector2.ZERO
	queue_redraw()


func _move(idx: int, pos: Vector2) -> void:
	if idx == _left_idx:
		_left_pos = pos
		left_vec = _to_vec(pos - _left_origin)
		queue_redraw()
	elif idx == _right_idx:
		_right_pos = pos
		right_vec = _to_vec(pos - _right_origin)
		queue_redraw()


func _to_vec(d: Vector2) -> Vector2:
	var v: Vector2 = d / STICK_R
	if v.length() > 1.0:
		v = v.normalized()
	if v.length() < DEAD:
		return Vector2.ZERO
	return v


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		_left_idx = -1
		_right_idx = -1
		left_vec = Vector2.ZERO
		right_vec = Vector2.ZERO
		boost_held = false
		for b in _buttons:
			b["touch"] = -1
		queue_redraw()


func _draw() -> void:
	var w: float = size.x
	var h: float = size.y
	# Faint hints where the sticks will appear.
	if _left_idx == -1:
		_draw_hint(Vector2(w * 0.2, h * 0.74))
	if _right_idx == -1:
		_draw_hint(Vector2(w * 0.8, h * 0.74))
	if _left_idx != -1:
		_draw_stick(_left_origin, _left_pos)
	if _right_idx != -1:
		_draw_stick(_right_origin, _right_pos)
	for b in _buttons:
		_draw_button(b)


func _draw_hint(c: Vector2) -> void:
	draw_arc(c, STICK_R, 0.0, TAU, 48, Color(0.5, 0.9, 1.0, 0.16), 2.0, true)


func _draw_stick(origin: Vector2, pos: Vector2) -> void:
	var knob: Vector2 = origin + (pos - origin).limit_length(STICK_R)
	draw_circle(origin, STICK_R, Color(1.0, 1.0, 1.0, 0.06))
	draw_arc(origin, STICK_R, 0.0, TAU, 48, Color(0.5, 0.9, 1.0, 0.55), 3.0, true)
	draw_circle(knob, 36.0, Color(0.5, 0.9, 1.0, 0.30))
	draw_arc(knob, 36.0, 0.0, TAU, 32, Color(0.75, 1.0, 1.0, 0.90), 3.0, true)


func _draw_button(b: Dictionary) -> void:
	var r: Rect2 = b["rect"]
	var pressed: bool = int(b["touch"]) != -1
	var fill: Color = Color(0.05, 0.10, 0.18, 0.80 if pressed else 0.52)
	var line: Color = Color(0.45, 0.88, 1.0, 0.95 if pressed else 0.60)
	if bool(b["round"]):
		draw_circle(r.get_center(), r.size.x * 0.5, fill)
		draw_arc(r.get_center(), r.size.x * 0.5, 0.0, TAU, 40, line, 3.0, true)
	else:
		draw_rect(r, fill, true)
		draw_rect(r, line, false, 2.0)
	if _font != null:
		var pos: Vector2 = Vector2(r.position.x, r.position.y + r.size.y * 0.5 + 7.0)
		draw_string(_font, pos, String(b["text"]), HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 20, Color(0.86, 0.97, 1.0, 0.96))
